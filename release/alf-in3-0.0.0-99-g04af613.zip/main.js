/**
 * Porovná aktuálnu URL so stepUrl.
 * - currentUrl: plná URL stránky (origin + path + query).
 * - stepUrl: len path + query (napr. "/app/.../{id}/...?krok=1"), {id} = wildcard pre ľubovoľný segment.
 * Vráti true, ak:
 *   - path po nahradení {id} sedí
 *   - všetky query parametre zo stepUrl sú prítomné v aktuálnej URL s rovnakými hodnotami
 *     (aktuálna URL môže mať navyše ďalšie parametre).
 */
function evaluateCondition(condition) {
  if (!condition) return true;
  const vw = document.documentElement.clientWidth || window.innerWidth;
  const vh = document.documentElement.clientHeight || window.innerHeight;
  // fast path: handle simple "viewport.width/height OP number" patterns without eval
  const m = String(condition).trim().match(/^viewport\.(width|height)\s*(>=|<=|>|<|===|==|!==|!=)\s*(\d+)$/);
  if (m) {
    const val = m[1] === 'width' ? vw : vh;
    const threshold = Number(m[3]);
    let result;
    switch (m[2]) {
      case '>':   result = val >   threshold; break;
      case '<':   result = val <   threshold; break;
      case '>=':  result = val >=  threshold; break;
      case '<=':  result = val <=  threshold; break;
      case '===': case '==':  result = val === threshold; break;
      case '!==': case '!=':  result = val !== threshold; break;
      default:    result = true;
    }
    console.log(`ALF condition [${condition}] → vw=${vw} vh=${vh} → ${result}`);
    return result;
  }
  // fallback for complex expressions
  try {
    const viewport = { width: vw, height: vh };
    const device = '';
    const result = Boolean(new Function('device', 'viewport', `return (${condition})`)(device, viewport));
    console.log(`ALF condition (eval) [${condition}] → vw=${vw} vh=${vh} → ${result}`);
    return result;
  } catch (e) {
    console.warn('ALF evaluateCondition: failed to evaluate condition', condition, e);
    return true;
  }
}

// New schema dropped `step.url` entirely (assert.pre/post with urlMatches(...)
// took over its job). Recover an equivalent path pattern for the pre-fill
// matching below, so autofill-on-navigation keeps working for new-format
// scenarios too.
function getStepUrlPattern(step) {
  if (!step || typeof step !== "object") return null;
  if (typeof step.url === "string" && step.url.trim()) return step.url.trim();
  const assert = step.assert;
  const lines = typeof assert === "string"
    ? assert.split(/\r?\n/)
    : Array.isArray(assert)
      ? assert
      : assert && typeof assert === "object"
        ? [...(Array.isArray(assert.pre) ? assert.pre : []), ...(Array.isArray(assert.post) ? assert.post : [])]
        : [];
  for (const raw of lines) {
    const line = String(raw).trim();
    const m = /^urlMatches\(\s*["']([^"']+)["']\s*\)$/.exec(line);
    if (m) return m[1];
  }
  return null;
}

// Old schema marked the login step with the `url: "login"` sentinel (which
// urlMatchesStep always treats as a match). The new schema dropped `url`
// entirely, so detect the same step by its shape instead: it fills the
// preset's auth_user/auth_pass via the `#preset` map marker.
function isLoginStep(step) {
  if (!step || typeof step !== "object") return false;
  const stepUrl = step.url != null ? String(step.url).trim().toLowerCase() : "";
  if (stepUrl === "login") return true;
  const map = step.map;
  if (!map || typeof map !== "object") return false;
  return Object.entries(map).some(([key, value]) => {
    if (!/#preset$/i.test(String(key))) return false;
    return value === "auth_user" || value === "auth_pass";
  });
}

function urlMatchesStep(currentUrl, stepUrl) {
  if (!currentUrl || !stepUrl) return false;
  const stepUrlNormalized = String(stepUrl).trim().toLowerCase();
  if (stepUrlNormalized === "login") {
    return true;
  }
  try {
    const curr = new URL(currentUrl);
    const currentPath = curr.pathname;
    const currentSearch = curr.search || "";

    // Trailing bare "#" (empty fragment) carries no navigational meaning and
    // is often gone from the real URL by the time the SPA settles — strip it
    // so it doesn't force an impossible exact-suffix match below.
    const stepUrlNoEmptyHash = stepUrl.replace(/#$/, "");

    const qPos = stepUrlNoEmptyHash.indexOf("?");
    const stepPath = qPos >= 0 ? stepUrlNoEmptyHash.slice(0, qPos) : stepUrlNoEmptyHash;
    const stepSearch = qPos >= 0 ? stepUrlNoEmptyHash.slice(qPos) : "";

    const stepSegments = stepPath.split("/").filter(Boolean);
    const currSegments = currentPath.split("/").filter(Boolean);
    if (stepSegments.length !== currSegments.length) return false;

    const idIndex = stepSegments.indexOf("{id}");
    const normalizedCurr = currSegments.map((seg, i) => (i === idIndex ? "{id}" : seg)).join("/");
    const normalizedPath = "/" + normalizedCurr + currentSearch;
    const stepPathAndQuery = (stepPath.startsWith("/") ? stepPath : "/" + stepPath) + stepSearch;

    // Path (vrátane query stringu) musí mať rovnakú štruktúru, ale query môže mať v currentUrl
    // ďalšie parametre navyše – stačí, že všetky parametre zo stepUrl sú prítomné.
    if (stepPath.startsWith("/")) {
      if (!normalizedPath.startsWith(stepPath)) {
        return false;
      }
    }

    if (!stepSearch) {
      // stepUrl nemá query – stačí zhodná path (už overená vyššie cez segments)
      return true;
    }

    const stepParams = new URLSearchParams(stepSearch);
    const currParams = new URLSearchParams(currentSearch);

    for (const [key, value] of stepParams.entries()) {
      if (!currParams.has(key)) return false;
      // ak v stepUrl je konkrétna hodnota (a nie je to {placeholder}), musí sedieť
      const isPlaceholder = value.startsWith("{") && value.endsWith("}");
      if (value !== "" && !isPlaceholder && currParams.get(key) !== value) {
        return false;
      }
    }

    return true;
  } catch (e) {
    return false;
  }
}

// Pamätáme si, pre ktorú URL A KTORÝ krok scenára už prebehol úspešný autofill,
// aby sme pri ďalšom stlačení Action na tej istej stránke pre TEN ISTÝ krok
// znova neprepisovali polia. Viacero krokov scenára často zdieľa jednu URL
// (SPA wizard, napr. "krok=2" postupne odhaľuje niekoľko pod-formulárov na tej
// istej stránke) – preto nestačí sledovať iba URL, inak sa autofill ďalšieho
// kroku na tej istej URL nesprávne preskočí.
let lastAutofillUrl = null;
let lastAutofillStepIndex = null;
const PENDING_LOGIN_AUTOFILL_KEY = "alfPendingLoginAutofill";

function setPendingLoginAutofill(scenario, stepIndex) {
  try {
    chrome.storage.local.set(
      {
        [PENDING_LOGIN_AUTOFILL_KEY]: {
          steps: scenario,
          stepIndex,
          createdAt: Date.now(),
        },
      },
      () => {},
    );
  } catch {
    // ignore
  }
}

function runPendingLoginAutofillOnLoad() {
  try {
    chrome.storage.local.get([PENDING_LOGIN_AUTOFILL_KEY], (result) => {
      const pending = result && result[PENDING_LOGIN_AUTOFILL_KEY];
      if (!pending || typeof pending !== "object") return;

      const scenario = pending.steps;
      const stepIndex = pending.stepIndex;
      const createdAt = pending.createdAt || 0;

      // Bezpečnostná poistka proti starému pending stavu.
      if (Date.now() - createdAt > 2 * 60 * 1000) {
        chrome.storage.local.remove(PENDING_LOGIN_AUTOFILL_KEY, () => {});
        return;
      }

      if (!Array.isArray(scenario) || stepIndex == null || stepIndex < 0 || stepIndex >= scenario.length) {
        chrome.storage.local.remove(PENDING_LOGIN_AUTOFILL_KEY, () => {});
        return;
      }

      const step = scenario[stepIndex];
      if (!isLoginStep(step)) {
        chrome.storage.local.remove(PENDING_LOGIN_AUTOFILL_KEY, () => {});
        return;
      }

      Promise.resolve(autofillScenarioForCurrentUrl(scenario, stepIndex))
        .catch(() => {
          // ignore
        })
        .finally(() => {
          chrome.storage.local.remove(PENDING_LOGIN_AUTOFILL_KEY, () => {});
        });
    });
  } catch {
    // ignore
  }
}

// Ako dlho čakať na element z mapy, ktorý v momente behu ešte nie je v DOM
// (typicky async-loaded tabuľky ako IspoAsyncTable, kde riadky dorenderujú
// až po API fetchi spustenom pri navigácii na krok).
const ALF_ELEMENT_WAIT_MS = 3000;
const ALF_ELEMENT_POLL_INTERVAL_MS = 150;

function __alfQueryByTestIdOrId(lookupKey) {
  const selectorId = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(lookupKey) : lookupKey;
  return document.querySelector(`[data-test-id="${selectorId}"]`) || document.getElementById(lookupKey);
}

function __alfWaitForElement(lookupKey, timeoutMs) {
  return new Promise((resolve) => {
    const existing = __alfQueryByTestIdOrId(lookupKey);
    if (existing) {
      resolve(existing);
      return;
    }
    let elapsed = 0;
    const timer = setInterval(() => {
      elapsed += ALF_ELEMENT_POLL_INTERVAL_MS;
      const el = __alfQueryByTestIdOrId(lookupKey);
      if (el || elapsed >= timeoutMs) {
        clearInterval(timer);
        resolve(el || null);
      }
    }, ALF_ELEMENT_POLL_INTERVAL_MS);
  });
}

/**
 * Vyplní polia podľa mapy kroku scenára, ak aktuálna URL sedí na krok na danom indexe.
 * Kroky idú vždy zaradom – používa sa len stepIndex, nie prehľadávanie podľa URL.
 */
async function autofillScenarioForCurrentUrl(scenario, stepIndex) {
  if (!Array.isArray(scenario) || !scenario.length) {
    return { filledCount: 0, matchedStepUrl: null };
  }
  if (stepIndex == null || stepIndex < 0 || stepIndex >= scenario.length) {
    return { filledCount: 0, matchedStepUrl: null };
  }

  const currentUrl = location.href;
  const step = scenario[stepIndex];
  if (!step || !step.map || typeof step.map !== "object") {
    return { filledCount: 0, matchedStepUrl: null };
  }

  const stepUrl = getStepUrlPattern(step);
  if (stepUrl) {
    if (!urlMatchesStep(currentUrl, stepUrl)) {
      // URL v scenári sa nezhoduje s aktuálnou URL – scenár je nesprávne nastavený.
      // Vypíšeme jasnú chybu a ukončíme spracovanie aktuálneho kroku.
      console.error("ALF scenario – URL nesedí na stepIndex", {
        stepIndex,
        expectedStepUrl: stepUrl,
        currentUrl,
      });
      throw new Error("ALF scenario – URL v kroku scenára sa nezhoduje s aktuálnou stránkou");
    }
  } else if (!isLoginStep(step)) {
    // New-format step with no urlMatches(...) assert to recover a pattern
    // from, and not the login step (which always proceeds) — nothing to
    // verify against, so skip silently rather than guessing.
    return { filledCount: 0, matchedStepUrl: null };
  }

  {
    const entries = Object.entries(step.map);
    let filledCount = 0;

    const fillEntry = async (dataTestId, value) => {
      if (dataTestId == null || dataTestId === "") return false;

      const rawKey = String(dataTestId);
      const hashPos = rawKey.indexOf("#");
      const lookupKey = hashPos >= 0 ? rawKey.slice(0, hashPos) : rawKey;
      const suffix = hashPos >= 0 ? rawKey.slice(hashPos + 1).toLowerCase() : "";
      const markers = suffix
        ? suffix
            .split(";")
            .map((s) => s.trim())
            .filter(Boolean)
        : [];
      const isLabelKeyLocal = suffix === "label";
      const isToggleKeyLocal = markers.includes("toggle");
      const isSearchKeyLocal = markers.includes("search");
      const isComboboxKeyLocal = markers.includes("combobox");
      const isComboboxFirstKeyLocal = markers.includes("combobox-first");
      const attachmentMarker = markers.find((m) => m.startsWith("attachment("));
      const attachmentFile = attachmentMarker
        ? attachmentMarker.replace(/^attachment\(['"]?/, "").replace(/['"]?\)$/, "")
        : null;

      if (isLabelKeyLocal) return false;

      if (attachmentFile) return "attachment";

      let el = __alfQueryByTestIdOrId(lookupKey);
      if (!el) {
        // Async-loaded tabuľky (napr. IspoAsyncTable) dorenderujú svoje riadky
        // až po tom, čo URL/step už zodpovedá – namiesto okamžitého vzdania sa
        // pár sekúnd počkáme, či sa element medzitým neobjaví v DOM.
        el = await __alfWaitForElement(lookupKey, ALF_ELEMENT_WAIT_MS);
      }
      if (!el) {
        console.warn(
          `ALF autofill – element pre "${lookupKey}" sa nenašiel v DOM ani po ${ALF_ELEMENT_WAIT_MS}ms čakaní (map záznam preskočený)`,
        );
        return false;
      }

      const valueStr = value != null ? String(value) : "";

      // Rozlíšenie podľa typu elementu
      if (el instanceof HTMLInputElement) {
        const t = el.type ? el.type.toLowerCase() : "";

        if (t === "checkbox" || t === "radio") {
          if (typeof el.click === "function") {
            el.click();
          }

          filledCount++;
          return true;
        } else {
          el.value = valueStr;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
        }
      } else if (el instanceof HTMLTextAreaElement) {
        el.value = valueStr;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if (el instanceof HTMLSelectElement) {
        el.value = valueStr;
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if ("value" in el) {
        // Iné elementy s .value (napr. custom komponenty)
        el.value = valueStr;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else {
        // Pre wrappery (napr. div/span s data-test-id):
        if (el.querySelector) {
          // 1) Toggle: vnorený checkbox/radio/role=checkbox
          if (isToggleKeyLocal) {
            const innerToggle = el.querySelector(
              'input[type="checkbox"], input[type="radio"], [role="checkbox"]',
            );
            if (innerToggle && typeof innerToggle.click === "function") {
              innerToggle.click();
              filledCount++;
              return true;
            }
          }

          // 2a) Combobox (explicit #combobox marker): otvor dropdown, potom klikni na opciu
          if (isComboboxKeyLocal) {
            const comboboxRoot =
              el.getAttribute("role") === "combobox"
                ? el
                : el.querySelector('[role="combobox"], .multiselect-wrapper');
            if (comboboxRoot && typeof comboboxRoot.click === "function") {
              comboboxRoot.click();
            }
            // Otvorenie dropdownu je async – opciu klikneme po renderovaní
            setTimeout(() => {
              const listbox =
                el.querySelector(".multiselect-options") ||
                el.querySelector('[role="listbox"]') ||
                (comboboxRoot && comboboxRoot.nextElementSibling);
              if (!listbox) return;
              const options = Array.prototype.slice.call(
                listbox.querySelectorAll('[role="option"], li'),
              );
              const wanted = valueStr.trim().toLowerCase();
              const target = options.find((opt) => {
                const labelText =
                  (opt.getAttribute && opt.getAttribute("aria-label")) ||
                  opt.textContent ||
                  "";
                const id = opt.id || "";
                let idValue = "";
                const idParts = id.split("-option-");
                if (idParts.length === 2) idValue = idParts[1];
                return (
                  wanted === labelText.trim().toLowerCase() ||
                  (idValue && wanted === idValue.trim().toLowerCase())
                );
              });
              if (target && typeof target.click === "function") {
                target.click();
              }
            }, 400);
            filledCount++;
            return true;
          }

          // 2a') Combobox-first (explicit #combobox-first marker): otvor dropdown, klikni prvú dostupnú opciu
          if (isComboboxFirstKeyLocal) {
            const comboboxRoot =
              el.getAttribute("role") === "combobox"
                ? el
                : el.querySelector('[role="combobox"], .multiselect-wrapper');
            if (comboboxRoot && typeof comboboxRoot.click === "function") {
              comboboxRoot.click();
            }
            // Otvorenie dropdownu je async – opciu klikneme po renderovaní
            setTimeout(() => {
              const listbox =
                el.querySelector(".multiselect-options") ||
                el.querySelector('[role="listbox"]') ||
                (comboboxRoot && comboboxRoot.nextElementSibling);
              if (!listbox) return;
              const options = Array.prototype.slice.call(
                listbox.querySelectorAll('[role="option"], li'),
              );
              const target = options.find((opt) => {
                const disabled =
                  (opt.getAttribute && opt.getAttribute("aria-disabled") === "true") ||
                  opt.disabled ||
                  (opt.classList && opt.classList.contains("is-disabled"));
                return !disabled;
              });
              if (target && typeof target.click === "function") {
                target.click();
              }
            }, 400);
            filledCount++;
            return true;
          }

          // 2b) Search: vnorený textový/combobox input + tlačidlo "vyhladat"
          if (isSearchKeyLocal) {
            const searchInput =
              el.querySelector('input[type="text"][role="combobox"]') ||
              el.querySelector('input[type="search"]') ||
              el.querySelector('input[type="text"]');

            if (searchInput) {
              searchInput.value = valueStr;
              searchInput.dispatchEvent(new Event("input", { bubbles: true }));
              searchInput.dispatchEvent(new Event("change", { bubbles: true }));
            }

            const searchButton = el.querySelector('[data-test-id="vyhladat"]');
            if (searchButton && typeof searchButton.click === "function") {
              searchButton.click();
            }

            // Po vyhľadaní (po krátkom oneskorení) automaticky zvolíme PRVÚ ne-disable-nutú možnosť
            setTimeout(() => {
              const listbox =
                el.querySelector(".multiselect-options") ||
                el.querySelector('[role="listbox"]');
              if (!listbox) return;

              const options = Array.prototype.slice.call(
                listbox.querySelectorAll('[role="option"], li'),
              );

              const target = options.find(
                (opt) =>
                  !opt.classList || !opt.classList.contains("is-disabled"),
              );

              if (target && typeof target.click === "function") {
                target.click();
              }
            }, 1000);

            filledCount++;
            return true;
          }

          // 3) Combobox (custom multiselect) – vyber možnosť podľa textu/aria-label
          const comboboxRoot =
            el.getAttribute("role") === "combobox"
              ? el
              : el.querySelector('[role="combobox"], .multiselect-wrapper');
          if (comboboxRoot) {
            const listbox =
              el.querySelector(".multiselect-options") ||
              el.querySelector('[role="listbox"]') ||
              comboboxRoot.nextElementSibling;
            if (listbox) {
              const options = Array.prototype.slice.call(
                listbox.querySelectorAll('[role="option"], li'),
              );
              const target = options.find((opt) => {
                const labelText =
                  (opt.getAttribute && opt.getAttribute("aria-label")) ||
                  opt.textContent ||
                  "";
                const id = opt.id || "";
                // napr. "...-multiselect-option-vydatazenaty" -> "vydatazenaty"
                let idValue = "";
                const idParts = id.split("-option-");
                if (idParts.length === 2) {
                  idValue = idParts[1];
                }

                const wanted = valueStr.trim().toLowerCase();
                const labelNorm = labelText.trim().toLowerCase();
                const idNorm = idValue.trim().toLowerCase();

                return wanted === labelNorm || (idNorm && wanted === idNorm);
              });

              if (target && typeof target.click === "function") {
                target.click();
                filledCount++;
                return true;
              }
            }
          }
        }

        // Fallback – pre obyčajné wrappery bez špeciálnej logiky
        el.textContent = valueStr;
      }
      filledCount++;
      return true;
    };

    // Každý #toggle môže odomknúť ďalšie polia v DOM – po ňom čakáme 1s.
    // Jedna globálna vlajka pre „už bol jeden toggle“ znamenala, že druhý
    // toggle sa spracoval hneď (zlé načasovanie) a prvý setTimeout znova vyplnil
    // zvyšok mapy (duplicity).
    const processEntryAt = (index) =>
      new Promise((resolveEntry) => {
        (async () => {
        if (index >= entries.length) {
          resolveEntry();
          return;
        }
        const [dataTestId, value] = entries[index];
        const keyStr = dataTestId != null ? String(dataTestId) : "";
        const hashIndex = keyStr.indexOf("#");
        const suffix = hashIndex >= 0 ? keyStr.slice(hashIndex + 1).toLowerCase() : "";
        const markers = suffix
          ? suffix
              .split(";")
              .map((s) => s.trim())
              .filter(Boolean)
          : [];
        const isLabelKey = suffix === "label";
        const isToggleKey = markers.includes("toggle");
        const isComboboxKey = markers.includes("combobox");
        const isComboboxFirstKey = markers.includes("combobox-first");
        const attachmentMarkerOuter = markers.find((m) => m.startsWith("attachment("));
        const attachmentFileOuter = attachmentMarkerOuter
          ? attachmentMarkerOuter.replace(/^attachment\(['"]?/, "").replace(/['"]?\)$/, "")
          : null;

        // Presunie sa na ďalší záznam a až po jeho (aj async) dobehnutí vyrieši aktuálny Promise.
        const next = () => {
          if (index < entries.length - 1) {
            processEntryAt(index + 1).then(resolveEntry);
          } else {
            resolveEntry();
          }
        };

        if (attachmentFileOuter) {
          const lookupKey = keyStr.slice(0, hashIndex);
          const selectorId = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(lookupKey) : lookupKey;
          const inputEl =
            document.querySelector(`[data-test-id="${selectorId}"] input[type="file"]`) ||
            document.querySelector(`[data-test-id="${selectorId}"]`) ||
            document.getElementById(lookupKey);

          const fileUrl = chrome.runtime.getURL(`storage/${attachmentFileOuter}`);
          fetch(fileUrl)
            .then((res) => res.arrayBuffer())
            .then((buffer) => {
              const file = new File([buffer], attachmentFileOuter);
              const dt = new DataTransfer();
              dt.items.add(file);
              const target = inputEl && inputEl.type === "file" ? inputEl : inputEl && inputEl.querySelector('input[type="file"]');
              if (target) {
                target.files = dt.files;
                target.dispatchEvent(new Event("change", { bubbles: true }));
                filledCount++;
              } else {
                console.warn("ALF attachment – nenašiel sa input[type=file] pre", lookupKey);
              }
            })
            .catch((e) => console.error("ALF attachment – chyba pri načítaní súboru:", attachmentFileOuter, e))
            .finally(next);
          return;
        }

        if (!isLabelKey) {
          try {
            await fillEntry(dataTestId, value);
          } catch (e) {
            console.error("ALF scenario autofill – fill error", e);
          }
        }

        if ((isToggleKey || isComboboxKey || isComboboxFirstKey) && index < entries.length - 1) {
          setTimeout(() => {
            processEntryAt(index + 1).then(resolveEntry);
          }, 600);
        } else {
          next();
        }
        })();
      });

    await processEntryAt(0);

  if (filledCount > 0) {
    lastAutofillUrl = currentUrl;
    lastAutofillStepIndex = stepIndex;
    return { filledCount, matchedStepUrl: stepUrl };
  }

  return { filledCount: 0, matchedStepUrl: null };
  }
}

function setNestedScopeValue(target, dottedPath, value) {
  if (!target || typeof target !== "object") return;
  if (!dottedPath) return;

  const parts = String(dottedPath)
    .split(".")
    .map((part) => part.trim())
    .filter(Boolean);

  if (parts.length === 0) return;

  let cursor = target;
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(part)) return;

    const isLast = i === parts.length - 1;
    if (isLast) {
      cursor[part] = value;
      return;
    }

    if (!cursor[part] || typeof cursor[part] !== "object") {
      cursor[part] = {};
    }
    cursor = cursor[part];
  }
}

function createAssertionContext(step, scenario, stepIndex) {
  const map = step && step.map && typeof step.map === "object" ? step.map : {};
  const data = {};

  for (const [key, value] of Object.entries(map)) {
    setNestedScopeValue(data, key, value);
  }

  return {
    step: step && typeof step === "object" ? step : {},
    steps: Array.isArray(scenario) ? scenario : [],
    map,
    data,
    stepIndex: Number.isInteger(stepIndex) ? stepIndex : -1,
  };
}

// Spracovanie akcií zo scenára z DevTools (ALF)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (
    !message ||
    (message.type !== "ALF_RUN_SCENARIO_ACTION" && message.type !== "ALF_RUN_ASSERTIONS")
  ) {
    return;
  }

  const scenario = message.steps;
  const stepIndex = message.stepIndex;
  if (!Array.isArray(scenario) || stepIndex == null || stepIndex < 0 || stepIndex >= scenario.length) {
    sendResponse && sendResponse({ ok: false, reason: "missing_scenario_or_index" });
    return;
  }

  const stepForClick = scenario[stepIndex];

  if (message.type === "ALF_RUN_ASSERTIONS") {
    try {
      const assertContext = createAssertionContext(stepForClick, scenario, stepIndex);
      const assertResults = runAssertions(stepForClick.assert, assertContext);
      sendResponse && sendResponse({ ok: true, assertResults });
    } catch (e) {
      console.error("ALF content script – chyba pri vyhodnocovaní assertácií:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return true;
  }

  if (stepForClick.condition === undefined || stepForClick.condition === null) {
    console.log(`ALF step [${stepIndex}] action=${stepForClick.action || stepForClick.actions} – no condition, running`);
  }
  if (!evaluateCondition(stepForClick.condition)) {
    console.log(`ALF step [${stepIndex}] action=${stepForClick.action || stepForClick.actions} – skipped by condition`);
    sendResponse && sendResponse({ ok: true, skipped: true });
    return true;
  }

  const actionName = stepForClick.action || stepForClick.actions;
  if (!actionName) {
    sendResponse && sendResponse({ ok: false, reason: "missing_action" });
    return;
  }

  try {
    // Autofill je teraz async (čaká aj na #toggle/#combobox setTimeout reťaz),
    // takže s klikom na action čakáme, kým naozaj celá mapa dobehne – inak by
    // sa kliklo skôr, než sa stihnú vyplniť polia odomknuté cez #toggle.
    const alreadyAutofilledThisStep =
      location.href === lastAutofillUrl && stepIndex === lastAutofillStepIndex;
    const autofillReadyPromise =
      !alreadyAutofilledThisStep
        ? Promise.resolve(autofillScenarioForCurrentUrl(scenario, stepIndex)).catch((e) => {
            console.error("ALF content script – autofill zlyhal:", e);
            return { filledCount: 0, matchedStepUrl: null };
          })
        : Promise.resolve({ filledCount: 0, matchedStepUrl: null });

    const actionStr = String(actionName);
    const actionHashPos = actionStr.indexOf("#");
    const actionSuffix = actionHashPos >= 0 ? actionStr.slice(actionHashPos + 1).toLowerCase() : "";
    const actionAttachmentMarker = actionSuffix.startsWith("attachment(") ? actionSuffix : null;
    const actionAttachmentFile = actionAttachmentMarker
      ? actionAttachmentMarker.replace(/^attachment\(['"]?/, "").replace(/['"]?\)$/, "")
      : null;

    // Celá zvyšná logika (klik na action) čaká, kým autofillReadyPromise naozaj
    // dobehne – vrátane #toggle/#combobox setTimeout reťaze – nie iba na jej
    // synchrónny "štart".
    autofillReadyPromise.then((autofillResult) => {
      const handledAutofill = autofillResult.filledCount > 0;

      if (actionAttachmentFile) {
        const actionLookupKey = actionHashPos >= 0 ? actionStr.slice(0, actionHashPos) : actionStr;
        const selectorId = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(actionLookupKey) : actionLookupKey;
        const wrapperEl =
          document.querySelector(`[data-test-id="${selectorId}"]`) ||
          document.getElementById(actionLookupKey);
        if (wrapperEl && typeof wrapperEl.click === "function") {
          wrapperEl.click();
        }
        sendResponse && sendResponse({ ok: true, found: true, clicked: true, autofilled: handledAutofill, attachmentManual: true });
        return;
      }

      const doActionClick = (phase) => {
        // 2) Klik na element podľa action kroku na stepIndex (krok, ktorý sa má vykonať)
        const actionKey = actionStr;
        const selector = `[data-test-id="${actionKey}"]`;
        const all = Array.prototype.slice.call(document.querySelectorAll("[data-test-id]"));
        let matches = Array.prototype.slice.call(document.querySelectorAll(selector));
        if (matches.length === 0) {
          const byId = document.getElementById(actionKey);
          if (byId) matches = [byId];
        }

        let clicked = false;
        if (matches[0]) {
          const candidate = matches[0];
          const clickable =
            (typeof candidate.click === "function" && candidate) ||
            candidate.querySelector(
              'button, [role="button"], a, input[type="submit"], input[type="button"]',
            );

          if (clickable && typeof clickable.click === "function") {
            clickable.click();
            clicked = true;
          }
        }
        return { clicked, matchCount: matches.length, allIdsSample: all.slice(0, 50).map((el) => el.getAttribute("data-test-id")) };
      };

      // Ak sme práve menili hodnoty (autofill), necháme Vue/vee-validate dobehnúť re-render
      // a až potom klikneme na "pokracovat". (Nie timeout, iba synchronizácia na event loop/render.)
      const clickResultPromise = handledAutofill
        ? Promise.resolve().then(
            () =>
              new Promise((resolve) => {
                requestAnimationFrame(() => {
                  requestAnimationFrame(() => resolve(doActionClick("deferred-raf2")));
                });
              }),
          )
        : Promise.resolve(doActionClick("immediate"));

      // 3) Po krátkom čase po Click skúsime autofill nasledujúceho kroku – pre prípad, že sa navigovalo na novú URL
      //    (typický flow: Action -> nová stránka -> automatický autofill podľa mapy ďalšieho kroku).
      const nextStepIndex = stepIndex + 1;
      const nextStep = Array.isArray(scenario) && nextStepIndex >= 0 && nextStepIndex < scenario.length
        ? scenario[nextStepIndex]
        : null;
      if (isLoginStep(nextStep)) {
        setPendingLoginAutofill(scenario, nextStepIndex);
      }
      setTimeout(() => {
        Promise.resolve(autofillScenarioForCurrentUrl(scenario, nextStepIndex)).catch(() => {
          // ignore delayed autofill errors
        });
      }, 800);

      clickResultPromise.then((clickResult) => {
        sendResponse &&
          sendResponse({
            ok: true,
            found: clickResult.matchCount > 0,
            clicked: !!clickResult.clicked,
            autofilled: handledAutofill,
            matchCount: clickResult.matchCount,
            allIdsSample: clickResult.allIdsSample,
          });
      });
    });
  } catch (e) {
    console.error("ALF content script – chyba pri spracovaní scenára:", e);
    sendResponse && sendResponse({ ok: false, error: String(e) });
  }

  // keep channel open only synchronously
  return true;
});

runPendingLoginAutofillOnLoad();

// ── QA highlight: zvýrazní všetky data-test-id (DTI) a data-block-id na stránke ──
let __alfHighlightObserver = null;
let __alfHighlightReapplyTimer = null;
const __ALF_LABEL_POSITIONS = ["top-left", "top-right", "bottom-left", "bottom-right"];
let __alfTestLabelPosition = "top-left";
let __alfTestMultiColor = false;
let __alfTestFilterMatchers = [];
let __alfShowDti = false;
let __alfShowBlocks = true;
// ACE taxonómia: ace- = atóm, acm- = molekula, aco- = organizmus, act- =
// šablóna, acp- = stránka - každá úroveň má vlastný nezávislý prepínač.
let __alfShowAtoms = false;
let __alfShowMolecules = false;
let __alfShowOrganisms = false;
let __alfShowTemplates = false;
let __alfShowPages = false;

function __alfUpdateHighlightState() {
  if (
    __alfShowDti ||
    __alfShowBlocks ||
    __alfShowAtoms ||
    __alfShowMolecules ||
    __alfShowOrganisms ||
    __alfShowTemplates ||
    __alfShowPages
  ) {
    __alfEnableHighlight();
  } else {
    __alfDisableHighlight();
  }
}

// Filter DTI: keď je zoznam termínov neprázdny, zvýrazní sa iba data-test-id,
// ktoré aspoň jednému z nich zodpovedá – užitočné pri stránkach s desiatkami
// DTI (napr. husto obsadené tabuľky), kde farby/pozície už nestačia.
function __alfBuildFilterMatcher(term) {
  const raw = String(term == null ? "" : term).trim();
  if (!raw) return null;

  if (raw.includes("*")) {
    const regexSource = raw
      .split("*")
      .map((part) => part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
      .join(".*");
    const regex = new RegExp(`^${regexSource}$`, "i");
    return (value) => regex.test(String(value == null ? "" : value));
  }

  const needle = raw.toLowerCase();
  return (value) => String(value == null ? "" : value).toLowerCase().includes(needle);
}

function __alfMatchesTestFilter(dataTestId) {
  if (!__alfTestFilterMatchers.length) return true;
  return __alfTestFilterMatchers.some((matcher) => matcher(dataTestId));
}

function __alfSetTestFilterTerms(rawTerms) {
  const terms = Array.isArray(rawTerms) ? rawTerms : [];
  __alfTestFilterMatchers = terms.map(__alfBuildFilterMatcher).filter(Boolean);
}

// 10 vzájomne dobre rozlíšiteľných farieb – striedajú sa po poradí, aby husto
// nabité DTI (napr. sidebar menu) neboli všetky rovnako červené a "kaša".
const __ALF_TEST_MULTI_COLORS = [
  "#ff3b30", // red
  "#ff9500", // orange
  "#ffcc00", // yellow
  "#34c759", // green
  "#00c7be", // teal
  "#30b0c7", // cyan
  "#007aff", // blue
  "#5856d6", // indigo
  "#af52de", // purple
  "#ff2d55", // pink
];

// APS (data-aps) je samostatná kategória zvýraznenia, nezávislá od TEST/BLOCK.
const __ALF_APS_COLOR = "#3b8830";

function __alfTestColorClass(index) {
  return `__qa-test-color-${index % __ALF_TEST_MULTI_COLORS.length}`;
}

// Vyberie čitateľnejšiu farbu textu (biela/tmavá) podľa jasu pozadia (YIQ) –
// napr. žltá potrebuje tmavý text, kým červená/modrá biely.
function __alfContrastTextColor(hex) {
  const clean = String(hex || "").replace("#", "");
  if (clean.length !== 6) return "white";
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  const yiq = (r * 299 + g * 587 + b * 114) / 1000;
  return yiq >= 150 ? "#1c1c1e" : "white";
}

function __alfRemoveHighlight() {
  document.getElementById("__qa-highlight-style")?.remove();
  document.querySelectorAll(".__qa-label").forEach((el) => el.remove());
  document.querySelectorAll(".__qa-box").forEach((el) => el.remove());
  const colorClasses = __ALF_TEST_MULTI_COLORS.map((_, i) => __alfTestColorClass(i));
  document
    .querySelectorAll(".__qa-test-highlight, .__qa-block-highlight")
    .forEach((el) => {
      el.classList.remove(
        "__qa-test-highlight",
        "__qa-block-highlight",
        "__qa-block-header",
        "__qa-block-main",
        "__qa-block-footer",
        "__qa-block-other",
        ...colorClasses,
      );
      // Odstráni inline outline nastavený __alfOwnerBlockColor pre DTI vo
      // vnútri ne-main blokov (viď __alfApplyHighlight).
      el.style.removeProperty("outline");
    });
  // ACE/ACM/ACO (__qa-aps-highlight) mali vlastné čistenie chýbajúce, takže
  // po vypnutí niektorej z ich úrovní (atom/molekula/organizmus) zostával
  // rámik+trieda "prilepený" na elemente navždy – __alfApplyHighlight ho
  // pri ďalšom prepočte pridá iba tým, čo aktuálne prejdú filtrom, ale nič
  // ho neodoberá tým, čo prestali vyhovovať.
  document.querySelectorAll(".__qa-aps-highlight").forEach((el) => {
    el.classList.remove("__qa-aps-highlight");
    el.style.removeProperty("outline");
  });
}

// Zaradenie bloku podľa najbližšej sekcie stránky
function __alfBlockRegion(el) {
  if (el.closest("header")) return "header";
  if (el.closest("footer")) return "footer";
  if (el.closest("main")) return "main";
  return "other";
}

const __ALF_BLOCK_COLORS = {
  header: "#af52de",
  main: "#007aff",
  footer: "#ff9500",
  other: "#5ac8fa",
};

// Niektoré elementy (select, input, textarea, img, ...) sú "replaced elements" –
// prehliadač im nevykreslí žiadne vnorené potomky, takže label sa musí pripnúť
// k document.body a pozicovať absolútne podľa getBoundingClientRect(), nie ako
// priamy child elementu.
function __alfCreateHighlightLabel(element, text, value, color, position, inside) {
  const label = document.createElement("div");
  label.className = "__qa-label";
  label.textContent = `${text}: ${value}`;
  label.dataset.alfAnchor = __ALF_LABEL_POSITIONS.includes(position) ? position : "bottom-right";
  if (inside) label.dataset.alfInside = "true";

  Object.assign(label.style, {
    position: "absolute",
    background: color,
    color: __alfContrastTextColor(color),
    border: "1px solid white",
    borderRadius: "4px",
    padding: "2px 6px",
    fontFamily: "monospace",
    fontSize: "11px",
    fontWeight: "bold",
    whiteSpace: "nowrap",
    zIndex: "2147483000",
    cursor: "pointer",
    userSelect: "text",
    pointerEvents: "auto",
    boxShadow: "0 1px 4px rgba(0,0,0,.4)",
  });

  // Pri prekrytí viacerých štítkov nad sebou: na hover vynesieme ten konkrétny
  // úplne na vrch (max z-index), po opustení sa vráti na pôvodnú úroveň.
  label.addEventListener("mouseenter", () => {
    label.style.zIndex = "2147483647";
  });
  label.addEventListener("mouseleave", () => {
    label.style.zIndex = "2147483000";
  });

  label.title = "Click to copy";
  label.addEventListener("click", async (e) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(value);
      const originalText = label.textContent;
      const originalColor = label.style.background;
      label.textContent = "✅ Copied!";
      label.style.background = "#28a745";
      setTimeout(() => {
        label.textContent = originalText;
        label.style.background = originalColor;
      }, 1500);
    } catch (err) {
      console.error("Clipboard error:", err);
    }
  });

  label.__alfTargetElement = element;
  document.body.appendChild(label);
  __alfPositionLabel(label, element, position, inside);
}

// "inside": štítok ostáva pripnutý PRI vnútornej hrane elementu (nepresahuje
// mimo neho, iba ju prekryje) – používa sa pre BLOCK štítky, kde by presah pod
// posledný blok na stránke inak zväčšoval document.scrollHeight a vytváral
// falošný prázdny priestor/scroll navyše (najmä pri blokoch pri spodku strany).
// display:contents elements (our <ace-is-*>/<acm-*> metadata wrappers) never
// have a box of their own - getBoundingClientRect() on them is always
// {0,0,0,0} even though their children render fully. When that happens fall
// back to the union of the element's children's rects so labels/clip checks
// still get a meaningful geometry instead of collapsing to the origin.
function __alfEffectiveRect(el) {
  const rect = el.getBoundingClientRect();
  if (rect.width > 0 || rect.height > 0) return rect;
  if (window.getComputedStyle(el).display !== "contents") return rect;

  let left = Infinity;
  let top = Infinity;
  let right = -Infinity;
  let bottom = -Infinity;
  let found = false;
  Array.prototype.forEach.call(el.children, (child) => {
    const childRect = child.getBoundingClientRect();
    if (childRect.width === 0 && childRect.height === 0) return;
    found = true;
    // getBoundingClientRect() vracia border-box, margin (napr. .page-title
    // { margin: 20px 0 }) je mimo neho - aby náš rámik obiehal skutočný
    // "vizuálny" priestor komponentu vrátane jeho vlastného odsadenia, pripočíta
    // sa computed margin dieťaťa k jeho rectu pred zjednotením.
    const childStyle = window.getComputedStyle(child);
    const marginTop = parseFloat(childStyle.marginTop) || 0;
    const marginRight = parseFloat(childStyle.marginRight) || 0;
    const marginBottom = parseFloat(childStyle.marginBottom) || 0;
    const marginLeft = parseFloat(childStyle.marginLeft) || 0;
    left = Math.min(left, childRect.left - marginLeft);
    top = Math.min(top, childRect.top - marginTop);
    right = Math.max(right, childRect.right + marginRight);
    bottom = Math.max(bottom, childRect.bottom + marginBottom);
  });

  if (!found) return rect;
  return {
    left,
    top,
    right,
    bottom,
    width: right - left,
    height: bottom - top,
    x: left,
    y: top,
  };
}

function __alfPositionLabel(label, element, position, inside) {
  const rect = __alfEffectiveRect(element);
  const scrollX = window.scrollX || window.pageXOffset || 0;
  const scrollY = window.scrollY || window.pageYOffset || 0;
  const pos = __ALF_LABEL_POSITIONS.includes(position) ? position : "bottom-right";
  const isTop = pos === "top-left" || pos === "top-right";
  const isRight = pos === "top-right" || pos === "bottom-right";

  label.style.left = `${(isRight ? rect.right : rect.left) + scrollX}px`;
  label.style.top = `${(isTop ? rect.top : rect.bottom) + scrollY}px`;

  // Roh, ku ktorému je label ukotvený, sa nesmie posunúť do stredu elementu –
  // preto translateX(-100%) len keď kotvíme na pravý okraj (rect.right).
  const parts = [];
  if (isRight) parts.push("translateX(-100%)");
  if (inside) {
    parts.push(isTop ? "translateY(2px)" : "translateY(-100%) translateY(-2px)");
  } else {
    parts.push(isTop ? "translateY(-100%) translateY(-2px)" : "translateY(2px)");
  }
  const baseTransform = parts.join(" ");

  // Uložíme si "čistú" transformáciu bez decluttering posunu, aby ju vedel
  // __alfDeclutterLabels pri každom prepočte resetnúť pred novým meraním.
  label.dataset.alfBaseTransform = baseTransform;
  label.style.transform = baseTransform;
  __alfClampLabelToViewport(label);
}

// display:contents elementy (naše <ace-is-*>/<acm-*> wrappery) nikdy nemajú
// vlastný box - CSS outline na nich preto vôbec nič nevykreslí (spec: box-level
// properties na display:contents elemente sa ignorujú), aj keď ich deti sú
// plne viditeľné. Namiesto pridania .__qa-*-highlight triedy na samotný
// element im vytvoríme samostatný absolútne pozicovaný "rámik" nad efektívnym
// rectom (rovnako ako __alfCreateHighlightLabel rieši labely).
function __alfCreateHighlightBox(element, color, borderStyle) {
  const box = document.createElement("div");
  box.className = "__qa-box";
  box.style.position = "absolute";
  box.style.border = `3px ${borderStyle || "solid"} ${color}`;
  box.style.zIndex = "2147482999";
  box.style.pointerEvents = "none";
  box.style.boxSizing = "border-box";
  box.__alfTargetElement = element;
  document.body.appendChild(box);
  __alfPositionHighlightBox(box, element);
}

function __alfPositionHighlightBox(box, element) {
  const rect = __alfEffectiveRect(element);
  const scrollX = window.scrollX || window.pageXOffset || 0;
  const scrollY = window.scrollY || window.pageYOffset || 0;
  box.style.left = `${rect.left + scrollX}px`;
  box.style.top = `${rect.top + scrollY}px`;
  box.style.width = `${rect.width}px`;
  box.style.height = `${rect.height}px`;
}

function __alfRepositionHighlightBoxes() {
  document.querySelectorAll(".__qa-box").forEach((box) => {
    const element = box.__alfTargetElement;
    if (element && document.contains(element)) {
      __alfPositionHighlightBox(box, element);
    }
  });
}

// Elementy pri samom okraji stránky (napr. logo v ľavom hornom rohu, avatar
// v pravom dolnom rohu sidebaru) majú štítok vykreslený mimo viditeľnej
// oblasti okna – prakticky neviditeľný/neklikateľný. Po zmeraní skutočnej
// (post-transform) pozície štítok jemne posunieme späť dovnútra viewportu.
function __alfClampLabelToViewport(label) {
  const margin = 2;
  const rect = label.getBoundingClientRect();
  const vw = document.documentElement.clientWidth || window.innerWidth;
  const vh = document.documentElement.clientHeight || window.innerHeight;

  let dx = 0;
  let dy = 0;
  if (rect.left < margin) dx = margin - rect.left;
  else if (rect.right > vw - margin) dx = (vw - margin) - rect.right;
  if (rect.top < margin) dy = margin - rect.top;
  else if (rect.bottom > vh - margin) dy = (vh - margin) - rect.bottom;

  if (dx === 0 && dy === 0) return;
  const left = parseFloat(label.style.left) || 0;
  const top = parseFloat(label.style.top) || 0;
  label.style.left = `${left + dx}px`;
  label.style.top = `${top + dy}px`;
}

// Susedné/vnorené elementy (napr. wrapper <li> menu položky + jej vnorený
// odznak/link) majú často takmer identický alebo prekrývajúci sa rect, takže
// ich labely by sa bez úpravy vykreslili navrstvené na sebe ("kaša"). Tento
// prechod ich po skutočnom rozmiestnení rozsunie pod seba, kým sa neprestanú
// prekrývať.
function __alfDeclutterLabels() {
  const labels = Array.prototype.slice.call(document.querySelectorAll(".__qa-label"));
  if (!labels.length) return;

  // Reset na pôvodnú pozíciu pred novým meraním (odstráni predchádzajúci posun).
  labels.forEach((label) => {
    label.style.transform = label.dataset.alfBaseTransform || label.style.transform;
  });

  const GAP = 2;
  const items = labels
    .map((label) => {
      const rect = label.getBoundingClientRect();
      return { label, top: rect.top, left: rect.left, right: rect.right, bottom: rect.bottom };
    })
    // Stabilné poradie zhora nadol, zľava doprava – horný/ľavší label ostáva na mieste.
    .sort((a, b) => a.top - b.top || a.left - b.left);

  const placed = [];
  items.forEach((item) => {
    let dy = 0;
    let guard = 0;
    let moved = true;
    while (moved && guard < 100) {
      moved = false;
      guard += 1;
      for (const p of placed) {
        const overlapsX = item.left < p.right && item.right > p.left;
        const overlapsY = item.top + dy < p.bottom && item.bottom + dy > p.top;
        if (overlapsX && overlapsY) {
          dy = p.bottom - item.top + GAP;
          moved = true;
        }
      }
    }

    if (dy !== 0) {
      const base = item.label.dataset.alfBaseTransform || "";
      item.label.style.transform = `${base} translateY(${dy}px)`;
    }
    __alfClampLabelToViewport(item.label);

    placed.push({ top: item.top + dy, left: item.left, right: item.right, bottom: item.bottom + dy });
  });
}

let __alfDeclutterRaf = null;
function __alfScheduleDeclutter() {
  if (__alfDeclutterRaf != null) return;
  __alfDeclutterRaf = requestAnimationFrame(() => {
    __alfDeclutterRaf = null;
    __alfDeclutterLabels();
  });
}

function __alfRepositionLabels() {
  document.querySelectorAll(".__qa-label").forEach((label) => {
    const element = label.__alfTargetElement;
    if (element && document.contains(element)) {
      __alfPositionLabel(label, element, label.dataset.alfAnchor, label.dataset.alfInside === "true");
    }
  });
  __alfRepositionHighlightBoxes();
  __alfScheduleDeclutter();
}

// Niektoré "collapsed" komponenty (napr. SubMenu v sidebari) neskrývajú svoje
// deti cez display:none – namiesto toho má IBA obalový <ul> height:0 +
// overflow:hidden, zatiaľ čo samotné <li> deti majú ďalej plnú prirodzenú
// výšku a bežný computed style. Taký element vlastný alfIsVisible() vyhodnotí
// ako viditeľný, hoci vizuálne je celý orezaný predkom na nulu. Tu prejdeme
// hore stromom a overíme, či element neleží mimo (alebo v nulovej) plochy
// niektorého orezávajúceho (overflow) predka.
function __alfIsClippedByAncestor(el) {
  const rect = __alfEffectiveRect(el);
  let node = el.parentElement;

  while (node && node !== document.documentElement) {
    const style = window.getComputedStyle(node);
    const clipsX = style.overflowX === "hidden" || style.overflowX === "clip" || style.overflowX === "scroll" || style.overflowX === "auto";
    const clipsY = style.overflowY === "hidden" || style.overflowY === "clip" || style.overflowY === "scroll" || style.overflowY === "auto";

    if (clipsX || clipsY) {
      const ancestorRect = node.getBoundingClientRect();
      if (ancestorRect.width <= 0 || ancestorRect.height <= 0) return true;

      const intersects =
        rect.left < ancestorRect.right &&
        rect.right > ancestorRect.left &&
        rect.top < ancestorRect.bottom &&
        rect.bottom > ancestorRect.top;
      if (!intersects) return true;
    }

    node = node.parentElement;
  }

  return false;
}

// Keď je zapnuté zobrazovanie DBI, chceme, aby pozornosť pútali iba DTI vo
// vnútri bloku "main" (tam prebiehajú reálne zmeny) – DTI vo všetkých
// ostatných blokoch dostanú jednotnú farbu zhodnú s farbou ich obalového
// bloku, namiesto vlastnej (červenej/multicolor) farby.
function __alfOwnerBlockColor(el) {
  if (!__alfShowBlocks) return null;
  const blockEl = el.closest("[data-block-id]");
  if (!blockEl) return null;
  const dbi = String(blockEl.getAttribute("data-block-id") || "").trim().toLowerCase();
  if (dbi === "main") return null;
  return __ALF_BLOCK_COLORS[__alfBlockRegion(blockEl)];
}

function __alfIsHighlightable(el) {
  const baseVisible = typeof alfIsVisible === "function" ? alfIsVisible(el) : true;
  if (!baseVisible) return false;
  return !__alfIsClippedByAncestor(el);
}

function __alfApplyHighlight() {
  __alfRemoveHighlight();

  const style = document.createElement("style");
  style.id = "__qa-highlight-style";
  style.textContent = `
    .__qa-test-highlight { outline: 3px solid #ff3b30 !important; }
    ${__ALF_TEST_MULTI_COLORS.map((c, i) => `.${__alfTestColorClass(i)} { outline: 3px solid ${c} !important; }`).join("\n    ")}
    .__qa-block-header { outline: 3px solid ${__ALF_BLOCK_COLORS.header} !important; }
    .__qa-block-main { outline: 3px solid ${__ALF_BLOCK_COLORS.main} !important; }
    .__qa-block-footer { outline: 3px solid ${__ALF_BLOCK_COLORS.footer} !important; }
    .__qa-block-other { outline: 3px solid ${__ALF_BLOCK_COLORS.other} !important; }
    .__qa-aps-highlight { outline: 3px solid ${__ALF_APS_COLOR} !important; }
  `;
  document.head.appendChild(style);

  // Skryté elementy (display:none/visibility:hidden na sebe, alebo orezané
  // predkom cez overflow:hidden – napr. zbalené SubMenu v sidebari) sa
  // nezvýrazňujú – inak sú labely nečitateľné "ako kaša". Ak je nastavený
  // filter DTI, zobrazia sa navyše iba tie, ktoré mu zodpovedajú.
  const testElements = __alfShowDti
    ? Array.prototype.filter.call(
        document.querySelectorAll("[data-test-id]"),
        (el) => __alfIsHighlightable(el) && __alfMatchesTestFilter(el.getAttribute("data-test-id")),
      )
    : [];
  testElements.forEach((el, i) => {
    const isContentsEl = window.getComputedStyle(el).display === "contents";
    const ownerColor = __alfOwnerBlockColor(el);
    let color;
    if (ownerColor) {
      color = ownerColor;
      if (isContentsEl) {
        __alfCreateHighlightBox(el, color);
      } else {
        el.classList.add("__qa-test-highlight");
        el.style.setProperty("outline", `3px solid ${color}`, "important");
      }
    } else {
      color = __alfTestMultiColor ? __ALF_TEST_MULTI_COLORS[i % __ALF_TEST_MULTI_COLORS.length] : "#ff3b30";
      if (isContentsEl) {
        __alfCreateHighlightBox(el, color);
      } else {
        el.classList.add("__qa-test-highlight");
        if (__alfTestMultiColor) el.classList.add(__alfTestColorClass(i));
      }
    }
    __alfCreateHighlightLabel(el, "TEST", el.getAttribute("data-test-id"), color, __alfTestLabelPosition);
  });

  const blockElements = __alfShowBlocks
    ? Array.prototype.filter.call(
        document.querySelectorAll("[data-block-id], acs-main, acs-sidebar, [class*='acs-']"),
        __alfIsHighlightable,
      )
    : [];
  blockElements.forEach((el) => {
    const region = el.tagName ? el.tagName.toLowerCase().replace("acs-", "") : (el.getAttribute("data-block-id") || "main");
    const color = __ALF_BLOCK_COLORS[region] || "#8a2be2";
    if (window.getComputedStyle(el).display === "contents") {
      __alfCreateHighlightBox(el, color);
    } else {
      el.classList.add("__qa-block-highlight", "__qa-block-" + region);
    }
    __alfCreateHighlightLabel(el, "SECTION", region, color, "bottom-right", true);
  });

  // ACE / ACM / ACO / ACT / ACP custom komponenty (vyhľadávané cez
  // __apsScanElements z aps-scraper.js) – každá úroveň (atóm/molekula/
  // organizmus/šablóna/stránka) má vlastný prepínač a farbu, aby sa dali
  // zapínať/vypínať nezávisle.
  const __alfApsLevelFor = (tag) => {
    if (tag.startsWith("ace-")) return "atom";
    if (tag.startsWith("acm-")) return "molecule";
    if (tag.startsWith("aco-")) return "organism";
    if (tag.startsWith("act-")) return "template";
    if (tag.startsWith("acp-")) return "page";
    return null;
  };
  // Celá ACE taxonómia ostáva v jednej "zelenej" rodine farieb, len v inom
  // odtieni podľa úrovne – atóm = stredná/sýta zelená, molekula = svetlá
  // zelená, organizmus/šablóna/stránka postupne tmavnú.
  const __ALF_APS_LEVEL_COLORS = {
    atom: "#22c55e",
    molecule: "#86efac",
    organism: "#166534",
    template: "#14532d",
    page: "#052e16",
  };
  const __ALF_APS_LEVEL_BORDER_STYLE = {
    atom: "solid",
    molecule: "dotted",
    organism: "solid",
    template: "dashed",
    page: "double",
  };
  const __ALF_APS_LEVEL_LABELS = {
    atom: "ACE",
    molecule: "ACM",
    organism: "ACO",
    template: "ACT",
    page: "ACP",
  };
  const anyApsLevelOn =
    __alfShowAtoms || __alfShowMolecules || __alfShowOrganisms || __alfShowTemplates || __alfShowPages;
  const apsElements = anyApsLevelOn
    ? Array.prototype.filter.call(
        typeof __apsScanElements === "function" ? __apsScanElements() : Array.prototype.filter.call(document.querySelectorAll("*"), (el) => {
          const tag = el.tagName ? el.tagName.toLowerCase() : "";
          return tag.startsWith("ace-") || tag.startsWith("acm-") || tag.startsWith("aco-") || tag.startsWith("act-") || tag.startsWith("acp-");
        }),
        (el) => {
          const tag = el.tagName ? el.tagName.toLowerCase() : "";
          const level = __alfApsLevelFor(tag);
          if (level === "atom" && !__alfShowAtoms) return false;
          if (level === "molecule" && !__alfShowMolecules) return false;
          if (level === "organism" && !__alfShowOrganisms) return false;
          if (level === "template" && !__alfShowTemplates) return false;
          if (level === "page" && !__alfShowPages) return false;
          if (!level) return false;
          return __alfIsHighlightable(el);
        },
      )
    : [];
  apsElements.forEach((el) => {
    const { name } = typeof __apsParseElement === "function" ? __apsParseElement(el) : { name: el.tagName.toLowerCase() };
    const tag = el.tagName ? el.tagName.toLowerCase() : "";
    const level = __alfApsLevelFor(tag) || "atom";
    const color = __ALF_APS_LEVEL_COLORS[level];
    const borderStyle = __ALF_APS_LEVEL_BORDER_STYLE[level] || "solid";
    if (window.getComputedStyle(el).display === "contents") {
      __alfCreateHighlightBox(el, color, borderStyle);
    } else {
      el.classList.add("__qa-aps-highlight");
      el.style.setProperty("outline", `3px ${borderStyle} ${color}`, "important");
    }
    __alfCreateHighlightLabel(el, __ALF_APS_LEVEL_LABELS[level], name, color, "bottom-right", true);
  });

  __alfDeclutterLabels();

  const filterNote = __alfTestFilterMatchers.length ? `, filter aktívny (${__alfTestFilterMatchers.length} termínov)` : "";
  console.log(
    `✅ Highlighted ${testElements.length} data-test-id elements, ${blockElements.length} data-block-id elements and ${apsElements.length} data-aps elements (skryté sa preskočili${filterNote})`,
  );
}

function __alfObserveDom() {
  if (!document.body) return;
  // attributeFilter: style/class chytí aj "collapse" komponenty, ktoré neskrývajú
  // deti cez pridanie/odobratie uzlov, ale iba prepnutím height/class na wrapperi
  // (napr. SubMenu v sidebari – klik na šípku nezmení childList, iba :style).
  __alfHighlightObserver.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["style", "class", "hidden", "aria-hidden", "aria-expanded"],
  });
}

// Spoločný debounced re-apply pre MutationObserver, klik a scroll – viac
// spúšťačov krátko po sebe sa zlejú do jedného prepočtu.
function __alfScheduleReapply() {
  clearTimeout(__alfHighlightReapplyTimer);
  __alfHighlightReapplyTimer = setTimeout(() => {
    // Observer odpojíme počas prekreslenia, aby naše vlastné labely nespustili ďalšiu slučku.
    if (__alfHighlightObserver) __alfHighlightObserver.disconnect();
    __alfApplyHighlight();
    if (__alfHighlightObserver) __alfObserveDom();
  }, 400);
}

function __alfOnScroll() {
  __alfRepositionLabels();
  // Scrollovateľné menu (napr. Reporting VIR/NIKA) môže odkryť/skryť ďalšie
  // data-test-id – nielen posunúť tie už zvýraznené, preto aj tu naplánujeme
  // plné prehodnotenie viditeľnosti.
  __alfScheduleReapply();
}

function __alfEnableHighlight() {
  __alfApplyHighlight();
  window.addEventListener("scroll", __alfOnScroll, true);
  window.addEventListener("resize", __alfRepositionLabels);
  document.addEventListener("click", __alfScheduleReapply, true);
  document.addEventListener("keyup", __alfScheduleReapply, true);
  if (__alfHighlightObserver) return;
  // Re-apply po zmenách DOM (Vue SPA dorenderúva polia/bloky dynamicky) – debounced.
  __alfHighlightObserver = new MutationObserver(__alfScheduleReapply);
  __alfObserveDom();
}

function __alfDisableHighlight() {
  if (__alfHighlightObserver) {
    __alfHighlightObserver.disconnect();
    __alfHighlightObserver = null;
  }
  clearTimeout(__alfHighlightReapplyTimer);
  window.removeEventListener("scroll", __alfOnScroll, true);
  window.removeEventListener("resize", __alfRepositionLabels);
  document.removeEventListener("click", __alfScheduleReapply, true);
  document.removeEventListener("keyup", __alfScheduleReapply, true);
  __alfRemoveHighlight();
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return;
  if (message.type === "ALF_TOGGLE_HIGHLIGHT") {
    try {
      __alfShowDti = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – highlight error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_TEST_LABEL_POSITION") {
    try {
      __alfTestLabelPosition = __ALF_LABEL_POSITIONS.includes(message.position) ? message.position : "top-left";
      if (__alfHighlightObserver) __alfApplyHighlight();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – test label position error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_TEST_MULTICOLOR") {
    try {
      __alfTestMultiColor = !!message.enabled;
      if (__alfHighlightObserver) __alfApplyHighlight();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – test multicolor error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_SHOW_BLOCKS") {
    try {
      __alfShowBlocks = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – show blocks error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_SHOW_ATOMS") {
    try {
      __alfShowAtoms = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – show atoms error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_SHOW_MOLECULES") {
    try {
      __alfShowMolecules = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – show molecules error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_SHOW_ORGANISMS") {
    try {
      __alfShowOrganisms = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – show organisms error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_SHOW_TEMPLATES") {
    try {
      __alfShowTemplates = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – show templates error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_SHOW_PAGES") {
    try {
      __alfShowPages = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – show pages error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_TEST_FILTER") {
    try {
      __alfSetTestFilterTerms(message.terms);
      if (__alfHighlightObserver) __alfApplyHighlight();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – test filter error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
});

// Po načítaní stránky obnov zvýraznenie, ak je v nastaveniach zapnuté
try {
  chrome.storage?.sync?.get?.(["ALF_HIGHLIGHT", "ALF_TEST_LABEL_POSITION", "ALF_TEST_MULTICOLOR", "ALF_TEST_FILTER", "ALF_SHOW_BLOCKS", "ALF_SHOW_APS", "ALF_SHOW_ATOMS", "ALF_SHOW_MOLECULES", "ALF_SHOW_ORGANISMS", "ALF_SHOW_TEMPLATES", "ALF_SHOW_PAGES"], (res) => {
    if (chrome.runtime.lastError) return;
    __alfTestLabelPosition = __ALF_LABEL_POSITIONS.includes(res && res.ALF_TEST_LABEL_POSITION) ? res.ALF_TEST_LABEL_POSITION : "top-left";
    __alfTestMultiColor = !!(res && (res.ALF_TEST_MULTICOLOR === true || res.ALF_TEST_MULTICOLOR === "true"));
    __alfShowBlocks = !(res && (res.ALF_SHOW_BLOCKS === false || res.ALF_SHOW_BLOCKS === "false"));
    // ALF_SHOW_APS je legacy kľúč z pôvodného jedného prepínača – ak je nastavený
    // a nový ALF_SHOW_ATOMS ešte nie je uložený, použije sa ako počiatočná hodnota atómov.
    const legacyShowAps = !!(res && (res.ALF_SHOW_APS === true || res.ALF_SHOW_APS === "true"));
    __alfShowAtoms = res && res.ALF_SHOW_ATOMS !== undefined
      ? !!(res.ALF_SHOW_ATOMS === true || res.ALF_SHOW_ATOMS === "true")
      : legacyShowAps;
    __alfShowMolecules = !!(res && (res.ALF_SHOW_MOLECULES === true || res.ALF_SHOW_MOLECULES === "true"));
    __alfShowOrganisms = !!(res && (res.ALF_SHOW_ORGANISMS === true || res.ALF_SHOW_ORGANISMS === "true"));
    __alfShowTemplates = !!(res && (res.ALF_SHOW_TEMPLATES === true || res.ALF_SHOW_TEMPLATES === "true"));
    __alfShowPages = !!(res && (res.ALF_SHOW_PAGES === true || res.ALF_SHOW_PAGES === "true"));
    __alfSetTestFilterTerms(res && res.ALF_TEST_FILTER);
    __alfShowDti = !!(res && (res.ALF_HIGHLIGHT === true || res.ALF_HIGHLIGHT === "true"));
    __alfUpdateHighlightState();
  });
} catch (e) {
  console.warn("ALF content script – nepodarilo sa načítať highlight nastavenie:", e);
}

