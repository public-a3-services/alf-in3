// Shared helpers for ALF DevTools.
const STORAGE_KEY_API_URL = "ALF_A3";
const STORAGE_KEY_PROJECT = "ALF_CLIENT";
const STORAGE_KEY_SUITE = "ALF_SUITE";
const STORAGE_KEY_PRESET = "ALF_PRESET";
const STORAGE_KEY_FLOW = "ALF_FLOW";
const STORAGE_KEY_HIGHLIGHT = "ALF_HIGHLIGHT";
const STORAGE_KEY_TEST_LABEL_POSITION = "ALF_TEST_LABEL_POSITION";
const STORAGE_KEY_TEST_MULTICOLOR = "ALF_TEST_MULTICOLOR";
const STORAGE_KEY_TEST_FILTER = "ALF_TEST_FILTER";
const STORAGE_KEY_SHOW_BLOCKS = "ALF_SHOW_BLOCKS";
const STORAGE_KEY_SHOW_APS = "ALF_SHOW_APS"; // legacy, viď STORAGE_KEY_SHOW_ATOMS
const STORAGE_KEY_SHOW_ATOMS = "ALF_SHOW_ATOMS";
const STORAGE_KEY_SHOW_MOLECULES = "ALF_SHOW_MOLECULES";
const STORAGE_KEY_SHOW_ORGANISMS = "ALF_SHOW_ORGANISMS";
const STORAGE_KEY_SHOW_TEMPLATES = "ALF_SHOW_TEMPLATES";
const STORAGE_KEY_SHOW_PAGES = "ALF_SHOW_PAGES";
const GET_SCENARIOS_PATH = "+/alf-engine/api/getAlfScenarios";
const POST_SCENARIO_PATH = "+/alf-engine/api/getAlfScenario";
const GET_SUITES_PATH = "+/alf-engine/api/getAlfSuites";
const GET_PRESETS_PATH = "+/alf-engine/api/getAlfPresets";
const GET_PROJECTS_PATH = "+/alf-engine/api/getAlfProjects";
const GET_AMS_INFO_PATH = "ams";
const ALF_LOG_TO_CONSOLE = false;

function $(id) {
  return document.getElementById(id);
}

function alfLog(level, ...args) {
  let options = { consoleOnly: false };
  const lastArg = args.length > 0 ? args[args.length - 1] : null;
  if (lastArg && typeof lastArg === "object" && lastArg.__alfLogOptions === true) {
    options = {
      ...options,
      consoleOnly: !!lastArg.consoleOnly,
    };
    args = args.slice(0, -1);
  }

  if (ALF_LOG_TO_CONSOLE || options.consoleOnly) {
    const consoleFn = level === "error" ? console.error : level === "warn" ? console.warn : console.log;
    consoleFn(...args);
  }

  if (options.consoleOnly) return;

  const logArea = $("logArea");
  if (!logArea) return;

  const line = document.createElement("div");
  line.className = `log-line log-${level}`;
  const time = new Date().toLocaleTimeString();
  const msg = args
    .map((a) => {
      if (typeof a === "string") return a;
      try {
        return JSON.stringify(a);
      } catch {
        return String(a);
      }
    })
    .join(" ");
  line.textContent = `[${time}] ${msg}`;
  logArea.insertBefore(line, logArea.firstChild);

  while (logArea.children.length > 200) {
    logArea.removeChild(logArea.lastChild);
  }
}

function buildScenarioUrl(baseUrl, path) {
  if (!baseUrl || typeof baseUrl !== "string") return null;
  const base = baseUrl.trim().replace(/\/$/, "");
  const segment = path || GET_SCENARIOS_PATH;
  return base ? `${base}/${segment}` : null;
}

function buildRequestUrl(baseUrl, path, params = {}) {
  const endpoint = buildScenarioUrl(baseUrl, path);
  if (!endpoint) return null;

  const url = new URL(endpoint);
  for (const [key, value] of Object.entries(params)) {
    if (value == null) continue;
    const text = String(value).trim();
    if (!text) continue;
    url.searchParams.set(key, text);
  }
  return url.toString();
}

async function loadStoredValue(key) {
  return new Promise((resolve) => {
    try {
      chrome.storage.sync.get([key], (res) => {
        if (chrome.runtime.lastError) {
          alfLog("warn", "chyba pri čítaní storage:", chrome.runtime.lastError);
          resolve(null);
          return;
        }
        resolve(res[key] || null);
      });
    } catch (e) {
      alfLog("warn", "výnimka pri čítaní storage:", e);
      resolve(null);
    }
  });
}

async function saveStoredValue(key, value) {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.sync.set({ [key]: value }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        resolve();
      });
    } catch (e) {
      reject(e);
    }
  });
}

async function loadStoredUrl() {
  return loadStoredValue(STORAGE_KEY_API_URL);
}

async function saveUrl(url) {
  return saveStoredValue(STORAGE_KEY_API_URL, url);
}

async function loadStoredProject() {
  return loadStoredValue(STORAGE_KEY_PROJECT);
}

async function saveProject(project) {
  return saveStoredValue(STORAGE_KEY_PROJECT, project);
}

async function fetchOptions(url) {
  const res = await fetch(url, {
    method: "GET",
    headers: { Accept: "application/json" },
  });

  if (!res.ok) throw new Error(`HTTP ${res.status}`);

  const data = await res.json();
  if (!Array.isArray(data)) throw new Error("Očakávané pole [{id, value}, ...]");
  return data;
}

async function fetchSuites(baseUrl) {
  const url = buildRequestUrl(baseUrl, GET_SUITES_PATH, { project: currentProject });
  if (!url) throw new Error("Chýba base URL pre suites");

  const res = await fetch(url, { method: "GET", headers: { Accept: "application/json" } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

async function fetchScenarios(baseUrl, suiteName) {
  const url = buildRequestUrl(baseUrl, GET_SCENARIOS_PATH, {
    suite: suiteName,
    preset: currentPresetValue(),
    project: currentProject,
  });
  if (!url) throw new Error("Chýba base URL");

  const res = await fetch(url, { method: "GET", headers: { Accept: "application/json" } });
  if (!res.ok) {
    const bodyText = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status}${bodyText ? `: ${bodyText}` : ""}`);
  }

  const data = await res.json();
  if (Array.isArray(data)) return data;
  if (data && Array.isArray(data.scenarios)) return data.scenarios;
  if (data && Array.isArray(data.data)) return data.data;
  throw new Error("Očakávané pole alebo objekt so scenarios/data");
}

async function fetchPresets(baseUrl) {
  const url = buildRequestUrl(baseUrl, GET_PRESETS_PATH, { project: currentProject });
  if (!url) throw new Error("Chýba base URL pre presety");
  const res = await fetch(url, { method: "GET", headers: { Accept: "application/json" } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

async function fetchProjects(baseUrl) {
  const url = buildRequestUrl(baseUrl, GET_PROJECTS_PATH);
  if (!url) throw new Error("Chýba base URL pre projekty");
  const res = await fetch(url, { method: "GET", headers: { Accept: "application/json" } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  if (!Array.isArray(data)) throw new Error("Očakávané pole projektov");
  return data;
}

function parseAmsInfo(rawText) {
  const text = rawText == null ? "" : String(rawText).trim();
  if (!text) return null;

  const unquoted = text.length >= 2 && text.startsWith('"') && text.endsWith('"') ? text.slice(1, -1) : text;
  const decoded = unquoted.replace(/\\n/g, "\n").replace(/\\r/g, "\r").replace(/\\t/g, "\t").replace(/\\"/g, '"');

  if (/<svg\b/i.test(decoded)) {
    const extractSvgTextById = (id) => {
      const escapedId = id.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const re = new RegExp(`<text[^>]*\\bid=["']${escapedId}["'][^>]*>([\\s\\S]*?)<\\/text>`, "i");
      const match = decoded.match(re);
      if (!match || !match[1]) return "";
      return match[1].replace(/<[^>]+>/g, "").trim();
    };

    const app = extractSvgTextById("name");
    const revision = extractSvgTextById("revision");
    const deploy = extractSvgTextById("deploy");
    const build = extractSvgTextById("build");
    const run = extractSvgTextById("run");
    const release = extractSvgTextById("release");
    const space = extractSvgTextById("space");

    return { app: app || "-", revision: revision || "-", build: deploy || build || run || "-", release: release || "-", space: space || "-" };
  }

  const lines = decoded.split(/\r?\n/).map((line) => line.trim()).filter((line) => line !== "");
  if (lines.length === 0) return null;

  const [app, revision, build, release, space] = lines;
  return { app: app || "-", revision: revision || "-", build: build || "-", release: release || "-", space: space || "-" };
}

async function fetchAmsInfo(baseUrl) {
  const endpoint = buildRequestUrl(baseUrl, GET_AMS_INFO_PATH);
  if (!endpoint) throw new Error("Chýba base URL pre AMS info");

  const res = await fetch(endpoint, {
    method: "GET",
    headers: { Accept: "text/plain, application/json;q=0.9, */*;q=0.8" },
  });

  if (!res.ok) throw new Error(`HTTP ${res.status}`);

  const text = await res.text();
  return parseAmsInfo(text);
}

function renderAmsInfo(amsInfo, errorMessage = "") {
  const amsInfoEl = $("amsInfo");
  if (!amsInfoEl) return;

  if (!amsInfo) {
    amsInfoEl.classList.toggle("error", !!errorMessage);
    amsInfoEl.textContent = errorMessage ? `A3 AMS: ${errorMessage}` : "A3 AMS: -";
    amsInfoEl.title = amsInfoEl.textContent;
    return;
  }

  amsInfoEl.classList.remove("error");
  amsInfoEl.textContent = `A3 AMS: ${amsInfo.app} | ${amsInfo.revision} | ${amsInfo.build} | ${amsInfo.release} | ${amsInfo.space}`;
  amsInfoEl.title = amsInfoEl.textContent;
}

async function postAlfScenario(baseUrl, filePath, presetName) {
  const endpoint = buildRequestUrl(baseUrl, POST_SCENARIO_PATH, { project: currentProject });
  if (!endpoint) throw new Error("Chýba base URL");

  const bodyData = { filePath };
  if (presetName) bodyData.preset = presetName;

  const res = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(bodyData),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${text || res.statusText}`);
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

async function getInspectedTabUrl() {
  return new Promise((resolve, reject) => {
    const inspected = chrome.devtools?.inspectedWindow;
    if (!inspected) {
      reject(new Error("DevTools inspectedWindow nie je k dispozícii."));
      return;
    }

    inspected.eval("location.href", (result, exception) => {
      if (exception) {
        const tabId = inspected.tabId;
        if (tabId == null) {
          reject(new Error(exception.value || "Nepodarilo sa získať URL stránky."));
          return;
        }
        chrome.tabs.get(tabId, (tab) => {
          if (chrome.runtime.lastError) {
            reject(new Error(exception.value || chrome.runtime.lastError.message));
            return;
          }
          resolve(tab?.url || "");
        });
        return;
      }
      resolve(typeof result === "string" ? result : "");
    });
  });
}
