// APS scraper trigger: asks the content script (aps-scraper.js) to scan the
// inspected page for [data-aps] elements, then writes the resulting base64
// payload to the clipboard from here (the panel), not from the content
// script - the panel reliably has focus right after the user's own click,
// while the content script's message-response context might not, which can
// make navigator.clipboard.writeText throw "Document is not focused".

function requestApsScrape(onDone) {
  const inspected = chrome.devtools?.inspectedWindow;
  const tabId = inspected?.tabId;
  if (tabId == null) return;

  chrome.tabs.sendMessage(tabId, { type: "ALF_SCRAPE_APS" }, (response) => {
    if (chrome.runtime.lastError) {
      alfLog("warn", "aps scrape:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      return;
    }
    if (!response || !response.ok) {
      alfLog("warn", "aps scrape failed:", response && response.error);
      return;
    }
    onDone(response);
  });
}

function scrapeAps() {
  requestApsScrape(async (response) => {
    const urlField = $("apsResultUrl");
    if (urlField) urlField.value = response.base64;

    try {
      await navigator.clipboard.writeText(response.base64);
      alfLog("info", `aps scrape: ${response.count} elementov skopírovaných do schránky (base64)`);
    } catch (e) {
      alfLog("warn", "aps scrape: zápis do schránky zlyhal:", e && e.message ? e.message : e);
    }
  });
}

// Client (currentBaseUrl, viď devtools-state.js) je ten istý a3/arch-it3ct
// host, na ktorom beží /@/alf-engine aj /@/aps – preto ho vieme priamo
// znovupoužiť aj tu, bez ďalšieho nastavovania.
// Používa "/+/" (nie "/@/") - tento prefix v arch-it3ct obchádza checkAccess
// (viď a3.public v arch-it3ct.yml), takže edit/view fungujú aj bez loginu.
// Payload je priamo v ceste (/+/acp/edit/<base64>), nie za "#" - vďaka tomu
// ho vidí aj server (rovnaká zmena ako v arch-it3ct editor.js), takže ručná
// zámena "edit" -> "view" v adresnom riadku funguje ako priamy náhľad.
const APS_MAX_URL_BASE64_LENGTH = 6000;

function buildApsUrl(kind, base64) {
  const base = currentBaseUrl ? currentBaseUrl.trim().replace(/\/$/, "") : "";
  if (!base) {
    alfLog("warn", "aps otvorenie zlyhalo: nie je nastavená A3 URL (pozri Client).");
    return null;
  }
  if (kind === "edit") {
    return `${base}/+/acp/edit/${base64}`;
  }
  return null;
}

// Payload presahujúci APS_MAX_URL_BASE64_LENGTH sa neuloží do URL, ale na
// server (POST /+/acp/save), ktorý vráti krátke id - rovnaký mechanizmus ako
// scheduleSaveShortUrl v arch-it3ct editor.js.
async function saveApsShortUrl(base, yaml) {
  const res = await fetch(`${base}/+/acp/save`, {
    method: "POST",
    headers: { "Content-Type": "text/yaml" },
    body: yaml
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const { editUrl } = await res.json();
  if (!editUrl) throw new Error("save: chýba editUrl v odpovedi");
  return `${base}${editUrl}`;
}

function openAps(kind) {
  requestApsScrape(async (response) => {
    const urlField = $("apsResultUrl");
    if (urlField) urlField.value = response.base64;

    const base = currentBaseUrl ? currentBaseUrl.trim().replace(/\/$/, "") : "";
    if (!base) {
      alfLog("warn", "aps otvorenie zlyhalo: nie je nastavená A3 URL.");
      return;
    }

    if (kind === "edit") {
      if (response.base64.length > APS_MAX_URL_BASE64_LENGTH) {
        try {
          const url = await saveApsShortUrl(base, response.yaml);
          window.open(url, "_blank", "noopener");
        } catch (e) {
          alfLog("error", `aps edit (save) zlyhalo: ${e.message}`);
          return;
        }
      } else {
        const url = buildApsUrl(kind, response.base64);
        if (url) window.open(url, "_blank", "noopener");
      }
    } else if (kind === "view") {
      try {
        const res = await fetch(`${base}/+/acp/view`, {
          method: "POST",
          headers: { "Content-Type": "text/yaml" },
          body: response.yaml
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        window.open(url, "_blank", "noopener");
      } catch (e) {
        alfLog("error", `aps view zlyhalo: ${e.message}`);
      }
    }
    alfLog("info", `aps ${kind}: otvorené s ${response.count} naskrapovanými elementmi`);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const btn = $("scrapeApsBtn");
  if (btn) btn.addEventListener("click", scrapeAps);

  const editBtn = $("apsEditBtn");
  if (editBtn) editBtn.addEventListener("click", () => openAps("edit"));

  const viewBtn = $("apsViewBtn");
  if (viewBtn) viewBtn.addEventListener("click", () => openAps("view"));

  const urlField = $("apsResultUrl");
  if (urlField) {
    urlField.addEventListener("click", () => {
      urlField.select();
    });
  }
});
