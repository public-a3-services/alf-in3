(async function() {
    const url = window.location.href;
    console.log("URL2: ",url);
    return
    
    try {
        const response = await fetch("https://httpbin.org/post", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url })
        });

        const data = await response.json();
        console.log(data);
        
        if (data.modify) {
            document.body.innerHTML = data.modify;
        }
    } catch (error) {
        console.error("Chyba pri komunikácii so serverom:", error);
    }
})();