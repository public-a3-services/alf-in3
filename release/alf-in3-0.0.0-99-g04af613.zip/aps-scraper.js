/**
 * ACP / APS scraper: scans the page for custom elements (<ace-is-*>, <acm-*>, <acs-*>)
 * or legacy [data-aps] elements, reads embedded <script type="application/json">
 * component attributes, and builds a YAML "page:" document with sections.
 */

function __apsKebabToPascal(str) {
  return str
    .split("-")
    .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
    .join("");
}

function __apsInferComponentName(tagName) {
  const lower = tagName.toLowerCase();
  if (lower.startsWith("ace-is-")) {
    return "Is" + __apsKebabToPascal(lower.replace("ace-is-", ""));
  }
  if (lower.startsWith("acm-v-")) {
    return "V" + __apsKebabToPascal(lower.replace("acm-v-", ""));
  }
  if (lower.startsWith("acm-")) {
    return __apsKebabToPascal(lower.replace("acm-", ""));
  }
  // Organizmus / šablóna / stránka (aco-/act-/acp-) - rovnaká konvencia ako
  // ace-/acm-: "-is-" podprefix znamená "Is" komponent (napr. aco-is-wizard-card
  // -> IsWizardCard), inak sa prefix jednoducho odstráni.
  if (/^ac[otp]-is-/.test(lower)) {
    return "Is" + __apsKebabToPascal(lower.replace(/^ac[otp]-is-/, ""));
  }
  if (/^ac[otp]-/.test(lower)) {
    return __apsKebabToPascal(lower.replace(/^ac[otp]-/, ""));
  }
  return __apsKebabToPascal(lower);
}

function __apsFindSection(el) {
  let curr = el.parentElement;
  while (curr && curr !== document.body) {
    const tag = curr.tagName ? curr.tagName.toLowerCase() : "";
    if (tag.startsWith("acs-")) {
      return tag.replace("acs-", "").replace("is-", "");
    }
    if (curr.dataset && curr.dataset.blockId) {
      return curr.dataset.blockId;
    }
    curr = curr.parentElement;
  }
  return "main";
}

function __apsMapProps(name, props) {
  const out = Object.assign({}, props);
  if ("modelValue" in out) {
    out.value = out.modelValue;
    delete out.modelValue;
  }
  return out;
}

function __apsParseElement(el) {
  const section = __apsFindSection(el);
  const scriptEl = el.querySelector('script[type="application/json"]');
  if (scriptEl && scriptEl.textContent) {
    try {
      const parsed = JSON.parse(scriptEl.textContent.trim());
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        // Meno komponentu sa odvodzuje z názvu tagu (napr. <ace-is-heading> ->
        // IsHeading) - v JSON-e ho netreba duplikovať, script nesie priamo
        // plochý props objekt.
        const name = __apsInferComponentName(el.tagName);
        return { name, props: __apsMapProps(name, parsed), section };
      }
    } catch (e) {
      // JSON parse error, fall through
    }
  }

  // Fallback to data-aps or tag name inference
  const raw = el.dataset ? el.dataset.aps : null;
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        const name = Object.keys(parsed)[0];
        return { name, props: __apsMapProps(name, parsed[name] || {}), section };
      }
    } catch (e) {}
    const variant = el.dataset.apsVariant;
    return { name: raw, props: variant ? { variant } : {}, section };
  }

  const name = __apsInferComponentName(el.tagName);
  return { name, props: {}, section };
}

// offsetParent === null je štandardný lacný spôsob, ako zistiť, že element
// (alebo niektorý z jeho predkov) má "display: none" - nefunguje len pre
// position:fixed elementy, čo je tu prijateľný kompromis (žiadny is-* prvok
// v aps-scraperi position:fixed nepoužíva). Vďaka tomuto sa do YAML nedostanú
// skryté kroky viacstupňového formulára (napr. fieldset[style*="display:none"]
// pre neaktívne wizard-kroky) - predtým sa scrapoval CELÝ DOM strom bez ohľadu
// na viditeľnosť, takže výstup obsahoval aj duplicitné/skryté komponenty zo
// všetkých krokov naraz.
function __apsIsVisible(el) {
  const style = getComputedStyle(el);
  if (style.display === "none" || style.visibility === "hidden") return false;
  // display:contents elements never have a box of their own (offsetParent is
  // spec'd to be null for them, same as display:none) even though their
  // children render fully and visibly - e.g. our <ace-is-*>/<acm-*> metadata
  // wrappers use display:contents on purpose so they don't disturb layout.
  if (style.display === "contents") return true;
  return el.offsetParent !== null;
}

function __apsScanElements() {
  const allElements = Array.prototype.slice.call(
    document.querySelectorAll("*")
  );

  return allElements.filter((el) => {
    const tag = el.tagName ? el.tagName.toLowerCase() : "";
    return (
      (tag.startsWith("ace-") ||
        tag.startsWith("acm-") ||
        tag.startsWith("aco-") ||
        tag.startsWith("act-") ||
        tag.startsWith("acp-")) &&
      __apsIsVisible(el)
    );
  });
}

// Elementy sú v HTML ploché ("ace-is-date" a "acm-v-card" sú v DOM na rôznych
// úrovniach vnárania, ale nič to nehovorí), preto sa strom skladá z reálneho
// DOM containmentu: pre každý naskrapovaný element sa nájde jeho najbližší
// naskrapovaný predok (ak existuje) - to je jeho rodič v strome. Elementy bez
// naskrapovaného predka sú root-y danej sekcie.
function __apsBuildTree(elements) {
  const nodes = elements.map((el) => ({ el, parsed: __apsParseElement(el), children: [] }));
  const byEl = new Map(nodes.map((n) => [n.el, n]));
  const roots = [];

  nodes.forEach((node) => {
    let curr = node.el.parentElement;
    let parentNode = null;
    while (curr) {
      if (byEl.has(curr)) {
        parentNode = byEl.get(curr);
        break;
      }
      curr = curr.parentElement;
    }
    if (parentNode) {
      parentNode.children.push(node);
    } else {
      roots.push(node);
    }
  });

  return roots;
}

function __apsYamlScalar(v) {
  if (v === null || v === undefined) return "null";
  if (typeof v === "boolean" || typeof v === "number") return String(v);
  if (typeof v === "object") return JSON.stringify(v);
  return JSON.stringify(String(v));
}

// Vykreslí jeden uzol stromu (a rekurzívne jeho deti pod props kľúčom
// "content:") na danej úrovni odsadenia. Molekuly/organizmy, ktoré v DOM
// obaľujú iné naskrapované komponenty (napr. VCard okolo IsStepTitle/IsDate/...,
// alebo VButtons okolo IsButton), tak namiesto plochého zoznamu sesterských
// položiek dostanú vnorený strom presne podľa skutočnej DOM hierarchie.
function __apsRenderNode(node, indent) {
  const { name, props } = node.parsed;
  const keys = Object.keys(props);
  const hasChildren = node.children.length > 0;
  const propIndent = indent + "    ";

  if (keys.length === 0 && !hasChildren) {
    return `${indent}- ${name}: {}`;
  }

  const lines = [`${indent}- ${name}:`];
  keys.forEach((k) => {
    lines.push(`${propIndent}${k}: ${__apsYamlScalar(props[k])}`);
  });
  if (hasChildren) {
    lines.push(`${propIndent}content:`);
    node.children.forEach((child) => {
      lines.push(__apsRenderNode(child, propIndent + "  "));
    });
  }
  return lines.join("\n");
}

function __apsBuildYamlList(nodes) {
  return nodes.map((node) => __apsRenderNode(node, "")).join("\n");
}

function __apsIndentLines(text, indent) {
  return text.split("\n").map((line) => (line.length ? indent + line : line)).join("\n");
}

function __apsCleanUrl(url) {
  return String(url || "").replace(/^https?:\/\//i, "");
}

function __apsBuildFullYaml(roots) {
  const sectionsMap = {};

  // Unwrap IsPage root nodes so their children become direct section items
  const flattenedRoots = [];
  roots.forEach((node) => {
    if (node.parsed.name === "IsPage") {
      if (node.children && node.children.length > 0) {
        flattenedRoots.push(...node.children);
      }
    } else {
      flattenedRoots.push(node);
    }
  });

  flattenedRoots.forEach((node) => {
    const sec = node.parsed.section || "main";
    if (!sectionsMap[sec]) sectionsMap[sec] = [];
    sectionsMap[sec].push(node);
  });

  const sectionLines = [];
  Object.keys(sectionsMap).forEach((sec) => {
    const listYaml = __apsBuildYamlList(sectionsMap[sec]);
    if (listYaml.trim().length === 0) {
      sectionLines.push(`    ${sec}: []`);
    } else {
      sectionLines.push(`    ${sec}:\n` + __apsIndentLines(listYaml, "    "));
    }
  });

  return [
    "page:",
    `  name: ${JSON.stringify(__apsCleanUrl(location.href))}`,
    `  width: ${window.innerWidth || 1220}`,
    `  template: "is"`,
    `  theme: "light"`,
    "  debug: false",
    "  section:",
    ...sectionLines,
  ].join("\n");
}

function __apsScrape() {
  const elements = __apsScanElements();
  const tree = __apsBuildTree(elements);
  const yaml = __apsBuildFullYaml(tree);
  const base64 = __apsEncodeBase64Url(yaml);
  return { entries: elements.map(__apsParseElement), yaml, base64 };
}

function __apsEncodeBase64Url(str) {
  const bytes = new TextEncoder().encode(str);
  let binary = "";
  bytes.forEach((b) => {
    binary += String.fromCharCode(b);
  });
  const b64 = btoa(binary);
  return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "ALF_SCRAPE_APS") return;
  try {
    const { entries, yaml, base64 } = __apsScrape();
    sendResponse({ ok: true, yaml, base64, count: entries.length });
  } catch (e) {
    console.error("ALF content script – aps scrape error:", e);
    sendResponse({ ok: false, error: String(e) });
  }
  return true;
});
