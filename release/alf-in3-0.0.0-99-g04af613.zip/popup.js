const STORAGE_KEY_API_URL = "ALF_A3";
const DEFAULT_A3_URL = "https://a3.ugkk.dev/";

document.addEventListener("DOMContentLoaded", async () => {
  const versionEl = document.getElementById("version");
  const nameRowEl = document.getElementById("nameRow");
  const apiUrlSelect = document.getElementById("apiUrlSelect");
  const apiUrlInput = document.getElementById("apiUrl");
  const saveUrlBtn = document.getElementById("saveUrlBtn");

  try {
    const manifest = chrome.runtime.getManifest();
    if (versionEl) {
      versionEl.textContent = manifest.version || "neznáma";
    }
  } catch (e) {
    if (versionEl) {
      versionEl.textContent = "chyba pri čítaní verzie";
    }
  }

  // Select ukazuje na preset zodpovedajúci aktuálnej URL, alebo na
  // "Vlastná URL…" (prázdna value), ak URL v inpute žiadnemu presetu nesedí.
  const syncSelectToInput = () => {
    if (!apiUrlSelect || !apiUrlInput) return;
    const current = apiUrlInput.value.trim();
    const presetOptions = Array.from(apiUrlSelect.options).filter(opt => opt.value !== "");
    const matched = presetOptions.find(opt => opt.value === current);
    apiUrlSelect.value = matched ? matched.value : "";
  };

  // Načítanie A3 URL zo storage
  if (apiUrlInput) {
    try {
      const res = await chrome.storage.sync.get([STORAGE_KEY_API_URL]);
      apiUrlInput.value = res[STORAGE_KEY_API_URL] || DEFAULT_A3_URL;
    } catch (e) {
      apiUrlInput.value = DEFAULT_A3_URL;
    }
    syncSelectToInput();
  }

  if (apiUrlSelect) {
    apiUrlSelect.addEventListener("change", () => {
      if (apiUrlSelect.value && apiUrlInput) {
        apiUrlInput.value = apiUrlSelect.value;
      }
    });
  }

  if (apiUrlInput) {
    apiUrlInput.addEventListener("input", syncSelectToInput);
  }

  const saveUrl = async () => {
    if (!apiUrlInput) return;
    const url = apiUrlInput.value.trim() || DEFAULT_A3_URL;
    try {
      await chrome.storage.sync.set({ [STORAGE_KEY_API_URL]: url });
    } catch (e) {
      console.error("ALF popup – chyba pri ukladaní URL:", e);
    }
  };

  if (saveUrlBtn) {
    saveUrlBtn.addEventListener("click", saveUrl);
  }
});

