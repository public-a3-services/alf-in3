// Scenario loading and step execution flow for ALF DevTools.
let lastScenario = null;
let lastScenarioIndex = -1;
let lastScenarioFilePath = null;
const STEP_MODE_ACTION = "action";
const STEP_MODE_ASSERT = "assert";
let currentStepMode = STEP_MODE_ACTION;
const lastAssertResultsByStep = new Map();

// Values captured mid-scenario via captureText("testId", "name") — see
// resolveVarsInScenario()/harvestCapturedVars() below. Lives only in the
// devtools panel (not the content script, which reloads on every navigation)
// so it survives page loads and client switches for the whole run. Mirrors
// alf-playwright's runner.ts `variables`.
let scenarioVariables = {};

const VAR_PATTERN = /\{\{\s*([\w.-]+)\s*\}\}/g;

function substituteVars(value) {
  if (typeof value !== "string") return value;
  return value.replace(VAR_PATTERN, (match, name) =>
    Object.prototype.hasOwnProperty.call(scenarioVariables, name) ? scenarioVariables[name] : match);
}

function substituteVarsInAssert(assert) {
  if (typeof assert === "string") return substituteVars(assert);
  if (Array.isArray(assert)) return assert.map((line) => substituteVars(line));
  if (assert && typeof assert === "object") {
    const out = {};
    if (Array.isArray(assert.pre)) out.pre = assert.pre.map((line) => substituteVars(line));
    if (Array.isArray(assert.post)) out.post = assert.post.map((line) => substituteVars(line));
    return out;
  }
  return assert;
}

function substituteVarsInMap(map) {
  if (!map || typeof map !== "object") return map;
  const out = {};
  for (const [key, value] of Object.entries(map)) {
    out[key] = substituteVars(value);
  }
  return out;
}

// Sent to the content script instead of the raw scenario so main.js/
// assertions.js never need to know about {{name}} at all — same split of
// responsibility as alf-playwright (runner.ts substitutes, assert-executor.ts
// stays oblivious except for captureText itself, which just reports the
// value it read).
function resolveVarsInScenario(scenario) {
  if (!Array.isArray(scenario)) return scenario;
  return scenario.map((step) => {
    if (!step || typeof step !== "object") return step;
    return {
      ...step,
      map: substituteVarsInMap(step.map),
      assert: substituteVarsInAssert(step.assert),
    };
  });
}

// After ALF_RUN_ASSERTIONS resolves, pull any captureText() results into
// scenarioVariables so later steps' {{name}} can see them.
function harvestCapturedVars(assertResults) {
  const results = assertResults && Array.isArray(assertResults.results) ? assertResults.results : [];
  for (const r of results) {
    if (r && r.fn === "captureText" && r.info && r.info.varName) {
      scenarioVariables[r.info.varName] = r.info.captured != null ? String(r.info.captured) : "";
    }
  }
}

function getStepAssertionLines(step) {
  if (!step || typeof step !== "object") return [];
  if (typeof step.assert === "string") {
    return step.assert.split(/\r?\n/).map((line) => line.trim()).filter((line) => line !== "");
  }
  if (Array.isArray(step.assert)) {
    return step.assert.map((entry) => String(entry).trim()).filter((line) => line !== "");
  }
  // New ALF schema: assert: { pre: [...], post: [...] }. This panel previews
  // and runs all of a step's assertions in one shot, so pre + post are just
  // concatenated for display/execution here.
  if (step.assert && typeof step.assert === "object") {
    const pre = Array.isArray(step.assert.pre) ? step.assert.pre : [];
    const post = Array.isArray(step.assert.post) ? step.assert.post : [];
    return [...pre, ...post].map((entry) => String(entry).trim()).filter((line) => line !== "");
  }
  return [];
}

// The new schema dropped the old `url:` field entirely (the runtime never
// actually enforced it). For display and start/reset navigation we can still
// recover a representative path from a `urlMatches("...")` assertion, if the
// step has one.
function getStepUrlHint(step) {
  if (!step || typeof step !== "object") return null;
  if (typeof step.url === "string" && step.url.trim()) return step.url.trim();
  const lines = getStepAssertionLines(step);
  for (const line of lines) {
    const m = /^urlMatches\(\s*["']([^"']+)["']\s*\)$/.exec(line);
    if (m) return m[1];
  }
  return null;
}

function stepHasAssertions(step) {
  return getStepAssertionLines(step).length > 0;
}

// Synthetic marker the engine inserts between client segments of a
// multi-client scenario (`steps: { is: [...], vp: [...] }`) — no assert/map/
// action, just tells us which client's host to navigate to next.
function isClientSwitchStep(step) {
  return !!step && typeof step === "object" && "client" in step && Object.keys(step).length === 1;
}

// Mirrors resolveAllClientHosts() in alf-playwright/src/scenario-loader.ts —
// reads the raw preset object (as returned by getAlfPresets) for a given
// client's host under the new nested `client.<client>.host` shape.
function resolveClientHost(preset, client) {
  const host = preset && preset.data && preset.data.client && preset.data.client[client] && preset.data.client[client].host;
  if (typeof host !== "string" || !host) return null;
  const trimmed = host.trim();
  return trimmed.startsWith("http") ? trimmed : `https://${trimmed}`;
}

function setPrimaryButtonMode(mode) {
  currentStepMode = mode === STEP_MODE_ASSERT ? STEP_MODE_ASSERT : STEP_MODE_ACTION;
  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (!runScenarioStepBtn) return;
  runScenarioStepBtn.textContent = currentStepMode === STEP_MODE_ASSERT ? "Assert" : "Action";
  runScenarioStepBtn.classList.toggle("mode-assert", currentStepMode === STEP_MODE_ASSERT);
}

function updateActionButtonState() {
  const runScenarioStepBtn = $("runScenarioStepBtn");
  const resetScenarioBtn = $("resetScenarioBtn");
  const prevScenarioStepBtn = $("prevScenarioStepBtn");
  const apiSelect = $("apiSelect");
  if (!runScenarioStepBtn && !resetScenarioBtn) return;

  if (!apiSelect || !apiSelect.value || !String(apiSelect.value).trim()) {
    if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
    if (prevScenarioStepBtn) prevScenarioStepBtn.disabled = true;
    return;
  }

  if (!Array.isArray(lastScenario) || lastScenarioIndex < 0 || lastScenarioIndex >= lastScenario.length) {
    if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
    if (prevScenarioStepBtn) prevScenarioStepBtn.disabled = true;
    return;
  }

  if (runScenarioStepBtn) runScenarioStepBtn.disabled = false;
  if (prevScenarioStepBtn) prevScenarioStepBtn.disabled = lastScenarioIndex <= 0;
}

function getDelayMsForStep(step) {
  if (!step || typeof step !== "object") return 500;
  const mapKeys = step.map && typeof step.map === "object" ? Object.keys(step.map) : [];
  const hasDelayedKeys = mapKeys.some((k) => /#toggle/i.test(String(k)) || /#search/i.test(String(k)));
  if (hasDelayedKeys) return 2000;
  if (mapKeys.length > 0) return 1000;
  return 500;
}

function applyDelayForCurrentStep() {
  if (!Array.isArray(lastScenario) || lastScenarioIndex < 0 || lastScenarioIndex >= lastScenario.length) {
    updateActionButtonState();
    return;
  }
  const step = lastScenario[lastScenarioIndex];
  const delayMs = getDelayMsForStep(step);
  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
  if (delayMs > 0) setTimeout(() => updateActionButtonState(), delayMs);
  else updateActionButtonState();
}

function renderAssertionResults(assertResults) {
  const section = $("assertSection");
  const container = $("assertResult");
  const summary = $("assertSummary");
  if (!section || !container) return;

  if (!assertResults || !Array.isArray(assertResults.results)) {
    section.style.display = "none";
    return;
  }

  const results = assertResults.results;
  if (results.length === 0) {
    if (summary) {
      summary.textContent = "(0/0)";
      summary.style.color = "#9ca3af";
    }
    container.innerHTML = "";
    const div = document.createElement("div");
    div.className = "assert-item";
    div.textContent = "No assertions for this step.";
    container.appendChild(div);
    section.style.display = "block";
    return;
  }

  const passedCount = results.filter((r) => r.passed).length;
  const total = results.length;
  if (summary) {
    summary.textContent = `(${passedCount}/${total})`;
    summary.style.color = passedCount === total ? "#3fb950" : "#f85149";
  }

  container.innerHTML = "";
  for (const r of results) {
    const div = document.createElement("div");
    div.className = `assert-item ${r.passed ? "pass" : "fail"}`;
    const icon = r.passed ? "✓" : "✗";
    const label = r.raw || (r.fn ? `${r.fn}(${(r.args || []).join(", ")})` : "(neznáma assertácia)");
    const err = r.error ? ` — ${r.error}` : "";
    div.textContent = `${icon} ${label}${err}`;
    container.appendChild(div);
  }

  section.style.display = "block";
}

function renderAssertionPreview(step) {
  const section = $("assertSection");
  const container = $("assertResult");
  const summary = $("assertSummary");
  if (!section || !container) return;

  const lines = getStepAssertionLines(step);
  if (lines.length === 0) {
    renderAssertionResults({ passed: true, results: [] });
    return;
  }

  if (summary) {
    summary.textContent = `(0/${lines.length}) pending`;
    summary.style.color = "#9ca3af";
  }

  container.innerHTML = "";
  for (const line of lines) {
    const div = document.createElement("div");
    div.className = "assert-item";
    div.textContent = `- ${line}`;
    container.appendChild(div);
  }

  section.style.display = "block";
}

function syncCurrentStepModeAndAssertions() {
  if (!Array.isArray(lastScenario) || lastScenarioIndex < 0 || lastScenarioIndex >= lastScenario.length) {
    setPrimaryButtonMode(STEP_MODE_ACTION);
    renderAssertionResults(null);
    updateActionButtonState();
    return;
  }

  const step = lastScenario[lastScenarioIndex] || {};
  const hasAsserts = stepHasAssertions(step);
  const cachedResults = lastAssertResultsByStep.get(lastScenarioIndex) || null;

  if (hasAsserts) {
    if (cachedResults) {
      setPrimaryButtonMode(STEP_MODE_ACTION);
      renderAssertionResults(cachedResults);
    } else {
      setPrimaryButtonMode(STEP_MODE_ASSERT);
      renderAssertionPreview(step);
    }
  } else {
    setPrimaryButtonMode(STEP_MODE_ACTION);
    renderAssertionResults({ passed: true, results: [] });
  }

  updateActionButtonState();
}

function renderCurrentStepInfo(indexOverride) {
  const apiResult = $("apiResult");
  if (!apiResult) return;
  apiResult.style.color = "";

  if (!Array.isArray(lastScenario) || lastScenario.length === 0) {
    apiResult.textContent = "Žiadny načítaný scenár.";
    return;
  }

  const totalSteps = lastScenario.length;
  const idx = typeof indexOverride === "number" && !Number.isNaN(indexOverride) ? indexOverride : lastScenarioIndex;
  if (idx < 0 || idx >= totalSteps) {
    apiResult.style.color = "#3fb950";
    apiResult.textContent = totalSteps > 0
      ? `✅ Všetkých ${totalSteps} krokov scenára bolo úspešne dokončených.`
      : "✅ Všetky kroky scenára boli úspešne dokončené.";
    return;
  }

  const step = lastScenario[idx] || {};

  if (isClientSwitchStep(step)) {
    apiResult.textContent = `Step ${idx + 1}/${totalSteps}\nswitch client → ${step.client}`;
    return;
  }

  const actionName = step.action || step.actions || null;
  const map = step.map && typeof step.map === "object" ? step.map : null;

  const lines = [
    `Step ${idx + 1}/${totalSteps}`,
    `name: ${step.name || "-"}`,
    `url: ${getStepUrlHint(step) || "-"}`,
    `action: ${actionName || "-"}`,
  ];

  const assertLines = getStepAssertionLines(step);
  if (assertLines.length > 0) {
    if (typeof step.assert === "string") {
      lines.push("assert: |");
      for (const line of assertLines) lines.push(`  ${line}`);
    } else {
      lines.push("assert:");
      for (const line of assertLines) lines.push(`  - ${line}`);
    }
  }

  if (map && Object.keys(map).length > 0) {
    lines.push("map:");
    for (const [k, v] of Object.entries(map)) {
      const valStr = v === null || v === undefined ? "" : String(v);
      lines.push(`  ${k}: ${valStr}`);
    }
  } else {
    lines.push("map: (žiadne položky)");
  }

  apiResult.textContent = lines.join("\n");
}

function extractScenarios(result) {
  if (!result || typeof result !== "object") return null;
  const feature = (result.feature && typeof result.feature === "object" && result.feature) || (result.alf && typeof result.alf === "object" && result.alf) || null;
  if (!feature || !Array.isArray(feature.steps)) return null;
  return feature.steps;
}

function getStartUrl(result) {
  if (!result || typeof result !== "object") return null;
  let pathOrUrl = null;
  // Old schema only: a separate `feature.start.url` field. The new schema
  // dropped `start`/`url` entirely — the engine already merges any relevant
  // start step into `feature.steps`, so there's nothing separate to read here
  // for new-format scenarios; the caller falls back to the preset's host.
  if (result.feature && typeof result.feature === "object" && result.feature.start && typeof result.feature.start === "object" && typeof result.feature.start.url === "string") {
    pathOrUrl = result.feature.start.url.trim();
  }
  if (!pathOrUrl && typeof result.startUrl === "string") pathOrUrl = result.startUrl.trim();
  if (!pathOrUrl && result.feature?.startUrl) pathOrUrl = String(result.feature.startUrl).trim();
  if (!pathOrUrl && result.alf?.startUrl) pathOrUrl = String(result.alf.startUrl).trim();
  if (!pathOrUrl) {
    const steps = extractScenarios(result);
    const firstStep = Array.isArray(steps) && steps.length ? steps[0] : null;
    pathOrUrl = getStepUrlHint(firstStep);
  }
  return pathOrUrl || null;
}

async function loadScenario() {
  const apiSelect = $("apiSelect");
  const apiResult = $("apiResult");
  const presetSelect = $("presetSelect");
  const filePath = apiSelect.value;
  const presetName = presetSelect ? presetSelect.value : "";

  if (!filePath) {
    apiResult.textContent = "";
    return;
  }
  if (!presetName) {
    apiResult.textContent = "Vyber preset, aby sa dal načítať scenár.";
    alfLog("warn", "scenár sa nenačítal, chýba preset.");
    return;
  }
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) {
    apiResult.textContent = "";
    return;
  }

  try {
    const result = await postAlfScenario(baseUrl, filePath, presetName);
    const scenarios = extractScenarios(result);
    if (!scenarios || scenarios.length === 0) return;

    // Old schema only: a separate top-level `start` step, passed through raw
    // (unnormalized) by the engine for .alf.md sources. The old runtime only
    // ever actually executed `start.action` when it was the register-flow
    // click (ACTIONS.register, 'registrovat') — see alf-playwright's
    // runner.ts/format-utils.js for the same rule. For every other flow
    // `start.action` was vestigial UI (e.g. opening a header avatar dropdown)
    // that later steps never depended on, and it was never clicked — keep
    // that behavior here instead of always prepending it as a live step.
    // New-format scenarios have no `start` field at all: the engine already
    // merges any relevant start step into `feature.steps` itself, so
    // `scenarios` (== feature.steps) is already the complete, ordered list.
    const legacyStartObj = (result && result.start) || (result && result.alf && result.alf.start) || (result && result.feature && result.feature.start) || null;
    const legacyStartAction = legacyStartObj && (legacyStartObj.action || legacyStartObj.actions);
    const isRegisterStart = legacyStartAction === "registrovat" || (typeof legacyStartAction === "string" && legacyStartAction.endsWith(".registrovat"));
    const combinedSteps = [];
    if (legacyStartObj && typeof legacyStartObj === "object" && isRegisterStart) {
      combinedSteps.push({
        name: legacyStartObj.name || "start",
        action: legacyStartAction,
        map: legacyStartObj.map || null,
      });
    }
    for (const s of scenarios) {
      if (s && typeof s === "object") combinedSteps.push(s);
    }

    lastScenario = combinedSteps;
    lastScenarioFilePath = filePath;
    lastScenarioIndex = 0;
    scenarioVariables = {};
    lastAssertResultsByStep.clear();

    renderCurrentStepInfo(0);
    syncCurrentStepModeAndAssertions();
    applyDelayForCurrentStep();

    try {
      const inspected = chrome.devtools?.inspectedWindow;
      const tabId = inspected?.tabId;
      const totalSteps = Array.isArray(lastScenario) ? lastScenario.length : 0;

      if (chrome.action && tabId != null && totalSteps) {
        chrome.action.setBadgeBackgroundColor({ color: "#2563eb", tabId });
        chrome.action.setBadgeText({ text: `0/${totalSteps}`, tabId });
      }
      const stepBadge = $("stepBadge");
      if (stepBadge && totalSteps) stepBadge.textContent = `0/${totalSteps}`;
    } catch (e) {
      alfLog("warn", "nepodarilo sa nastaviť badge:", e && e.message ? e.message : e);
    }

    const startUrl = getStartUrl(result);
    let presetUrl = null;
    let targetOrigin = null;
    if (presetName && currentPresetsMap.has(presetName)) {
      const preset = currentPresetsMap.get(presetName);
      // New-format presets nest the host under client.<client>.host; old ones
      // keep a flat `env` field. Mirrors resolveClientHost() (used for the
      // {client} switch marker) and alf-playwright's resolvePresetHost().
      const nestedUrl = resolveClientHost(preset, currentProject);
      const flatEnv = preset.env ? preset.env.trim() : "";
      let envUrl = nestedUrl || (flatEnv ? (flatEnv.startsWith("http") ? flatEnv : `https://${flatEnv}`) : "");
      if (envUrl) {
        try {
          presetUrl = envUrl;
          targetOrigin = new URL(envUrl).origin;
        } catch {}
      }
    }

    if (!startUrl) {
      if (presetUrl) {
        try {
          const inspected = chrome.devtools?.inspectedWindow;
          const tabId = inspected?.tabId;
          if (tabId != null) chrome.tabs.update(tabId, { url: presetUrl });
        } catch {}
      }
      return;
    }

    try {
      const inspected = chrome.devtools?.inspectedWindow;
      const tabId = inspected?.tabId;
      if (tabId != null) {
        if (!targetOrigin) {
          const currentHrefResult = await getInspectedTabUrl().catch(() => null);
          if (currentHrefResult) {
            try {
              const current = new URL(currentHrefResult);
              targetOrigin = current.origin;
            } catch {
              targetOrigin = null;
            }
          }
        }
        let targetUrl;
        if (startUrl.startsWith("http") || !targetOrigin) {
          targetUrl = startUrl;
        } else {
          const path = String(startUrl).trim();
          targetUrl = path.startsWith("/") ? targetOrigin + path : targetOrigin + "/" + path;
        }
        chrome.tabs.update(tabId, { url: targetUrl });
      }
    } catch (navErr) {
      alfLog("warn", "nepodarilo sa presmerovať stránku:", navErr && navErr.message ? navErr.message : navErr);
    }
  } catch (e) {
    alfLog("error", "chyba POST getAlfScenario:", e && e.message ? e.message : e);
    apiResult.textContent = e.message || String(e);
  }
}

function getCurrentStepContext() {
  const apiSelect = $("apiSelect");
  const apiResult = $("apiResult");
  const filePath = apiSelect.value;
  if (apiResult) apiResult.style.color = "";

  if (!filePath || !lastScenario || lastScenarioFilePath !== filePath) {
    apiResult.textContent = "Vyber scenár v comboboxe – načíta sa a presmeruje na start.";
    return null;
  }

  if (!Array.isArray(lastScenario) || lastScenarioIndex < 0 || lastScenarioIndex >= lastScenario.length) {
    const totalSteps = Array.isArray(lastScenario) ? lastScenario.length : 0;
    apiResult.style.color = "#3fb950";
    apiResult.textContent = totalSteps > 0
      ? `✅ Všetkých ${totalSteps} krokov scenára bolo úspešne dokončených.`
      : "✅ Všetky kroky scenára boli úspešne dokončené.";
    return null;
  }

  const step = lastScenario[lastScenarioIndex];
  if (!step) {
    apiResult.textContent = "Neplatný krok scenára.";
    return null;
  }

  const inspected = chrome.devtools?.inspectedWindow;
  const tabId = inspected?.tabId;
  if (tabId == null) {
    apiResult.textContent = "TabId nie je k dispozícii.";
    return null;
  }

  return { apiResult, filePath, step, tabId };
}

async function runCurrentStepAssertions() {
  const context = getCurrentStepContext();
  if (!context) return;
  const { step, tabId } = context;
  if (!stepHasAssertions(step)) {
    setPrimaryButtonMode(STEP_MODE_ACTION);
    renderAssertionResults({ passed: true, results: [] });
    updateActionButtonState();
    return;
  }

  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
  alfLog("info", `runAssertions [${lastScenarioIndex + 1}] url=${getStepUrlHint(step) || "-"}`);

  chrome.tabs.sendMessage(tabId, { type: "ALF_RUN_ASSERTIONS", steps: resolveVarsInScenario(lastScenario), stepIndex: lastScenarioIndex }, (response) => {
    if (chrome.runtime.lastError) {
      alfLog("warn", "chyba pri posielaní assert správy:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      updateActionButtonState();
      return;
    }

    if (!response || !response.ok) {
      const err = response && response.error ? response.error : "Nepodarilo sa vyhodnotiť assertácie.";
      renderAssertionResults({ passed: false, results: [{ fn: "", args: [], passed: false, raw: "(assert-runtime)", error: err }] });
      setPrimaryButtonMode(STEP_MODE_ACTION);
      updateActionButtonState();
      return;
    }

    const assertResults = response.assertResults || { passed: true, results: [] };
    harvestCapturedVars(assertResults);
    for (const resultItem of assertResults.results || []) {
      if (!resultItem.passed) {
        const errorMsg = resultItem.error ? ` — ${resultItem.error}` : "";
        alfLog("error", `assertion failed: [${resultItem.raw}]${errorMsg}`);
      } else if (resultItem.fn === "captureText" && resultItem.info) {
        alfLog("info", `captured "${resultItem.info.varName}" = "${resultItem.info.captured}"`, { __alfLogOptions: true, consoleOnly: true });
      } else if (resultItem.info && resultItem.info.message) {
        alfLog("warn", `assertions INFO: ${resultItem.info.message}`, { __alfLogOptions: true, consoleOnly: true });
      }
    }

    lastAssertResultsByStep.set(lastScenarioIndex, assertResults);
    renderAssertionResults(assertResults);
    setPrimaryButtonMode(STEP_MODE_ACTION);
    updateActionButtonState();
  });
}

async function runCurrentStepAction() {
  const context = getCurrentStepContext();
  if (!context) return;
  const { apiResult, step, tabId } = context;

  if (isClientSwitchStep(step)) {
    const presetSelect = $("presetSelect");
    const presetName = presetSelect ? presetSelect.value : "";
    const preset = presetName && currentPresetsMap.has(presetName) ? currentPresetsMap.get(presetName) : null;
    const nextHost = resolveClientHost(preset, step.client);
    if (!nextHost) {
      apiResult.textContent = `Preset neobsahuje host pre klienta "${step.client}".`;
      return;
    }
    alfLog("info", `switch client → ${step.client} (${nextHost})`);
    try {
      chrome.tabs.update(tabId, { url: `${nextHost}/` });
    } catch (e) {
      alfLog("warn", "nepodarilo sa prepnúť klienta:", e && e.message ? e.message : e);
    }
    const nextIndex = Math.min(lastScenarioIndex + 1, lastScenario.length);
    lastScenarioIndex = nextIndex;
    renderCurrentStepInfo(nextIndex);
    syncCurrentStepModeAndAssertions();
    applyDelayForCurrentStep();
    return;
  }

  const actionName = step.action || step.actions;
  if (!actionName) {
    apiResult.textContent = "Krok scenára nemá definovanú action/actions.";
    lastScenarioIndex = Math.min(lastScenarioIndex + 1, lastScenario.length);
    renderCurrentStepInfo(lastScenarioIndex);
    syncCurrentStepModeAndAssertions();
    applyDelayForCurrentStep();
    return;
  }

  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
  alfLog("info", `runScenarioStep [${lastScenarioIndex + 1}] action=${actionName} url=${getStepUrlHint(step) || "-"}`);

  chrome.tabs.sendMessage(tabId, { type: "ALF_RUN_SCENARIO_ACTION", steps: resolveVarsInScenario(lastScenario), stepIndex: lastScenarioIndex }, (response) => {
    if (chrome.runtime.lastError) {
      alfLog("warn", "chyba pri posielaní správy:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      updateActionButtonState();
      return;
    }

    if (!response || !response.ok) {
      alfLog("warn", "content script nevedel spracovať action:", actionName, response);
      updateActionButtonState();
      return;
    }

    if (response.skipped) {
      alfLog("info", `krok [${lastScenarioIndex + 1}] preskočený (condition)`);
      lastScenarioIndex = Math.min(lastScenarioIndex + 1, Array.isArray(lastScenario) ? lastScenario.length : 0);
      renderCurrentStepInfo(lastScenarioIndex);
      syncCurrentStepModeAndAssertions();
      setTimeout(() => runCurrentStepAction(), 0);
      return;
    }

    if (response.attachmentManual) {
      alfLog("info", "otvorený dialóg pre výber súboru. Vyber súbor manuálne a stlač Action.");
    }

    if (!response.found) {
      alfLog("warn", "element with data-test-id was not found:", actionName);
      updateActionButtonState();
      return;
    }

    const totalSteps = Array.isArray(lastScenario) ? lastScenario.length : 0;
    const nextIndex = Math.min(lastScenarioIndex + 1, totalSteps);
    try {
      if (chrome.action && totalSteps && tabId != null) {
        chrome.action.setBadgeText({ text: `${nextIndex}/${totalSteps}`, tabId });
      }
      const stepBadge = $("stepBadge");
      if (stepBadge && totalSteps) stepBadge.textContent = `${nextIndex}/${totalSteps}`;
    } catch (e) {
      alfLog("warn", "nepodarilo sa aktualizovať badge:", e && e.message ? e.message : e);
    }

    lastScenarioIndex = nextIndex;
    renderCurrentStepInfo(nextIndex);
    syncCurrentStepModeAndAssertions();
    applyDelayForCurrentStep();
  });
}

function prevScenarioStep() {
  if (!Array.isArray(lastScenario) || lastScenarioIndex <= 0) return;
  lastScenarioIndex -= 1;
  lastAssertResultsByStep.delete(lastScenarioIndex);
  renderCurrentStepInfo(lastScenarioIndex);
  syncCurrentStepModeAndAssertions();
  updateActionButtonState();

  try {
    const totalSteps = lastScenario.length;
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (chrome.action && tabId != null && totalSteps) {
      chrome.action.setBadgeText({ text: `${lastScenarioIndex}/${totalSteps}`, tabId });
    }
    const stepBadge = $("stepBadge");
    if (stepBadge) stepBadge.textContent = `${lastScenarioIndex}/${totalSteps}`;
  } catch {}
}

async function runScenarioStep() {
  if (currentStepMode === STEP_MODE_ASSERT) {
    await runCurrentStepAssertions();
    return;
  }
  await runCurrentStepAction();
}

async function resetScenario() {
  const apiSelect = $("apiSelect");
  const apiResult = $("apiResult");
  const filePath = apiSelect && apiSelect.value ? String(apiSelect.value) : "";

  if (!filePath || !Array.isArray(lastScenario) || lastScenarioFilePath !== filePath) {
    if (apiResult) apiResult.textContent = "Vyber scenár v comboboxe – načíta sa a presmeruje na start.";
    updateActionButtonState();
    return;
  }

  lastScenarioIndex = 0;
  scenarioVariables = {};
  lastAssertResultsByStep.clear();
  renderCurrentStepInfo(0);
  syncCurrentStepModeAndAssertions();
  applyDelayForCurrentStep();

  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    const totalSteps = lastScenario.length;
    if (chrome.action && tabId != null && totalSteps) chrome.action.setBadgeText({ text: `0/${totalSteps}`, tabId });
    const stepBadge = $("stepBadge");
    if (stepBadge && totalSteps) stepBadge.textContent = `0/${totalSteps}`;
  } catch (e) {
    alfLog("warn", "nepodarilo sa resetnúť badge:", e && e.message ? e.message : e);
  }

  try {
    const startStep = Array.isArray(lastScenario) && lastScenario.length > 0 ? lastScenario[0] : null;
    const startUrl = getStepUrlHint(startStep) || "";
    if (!startUrl) return;

    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;

    const currentHrefResult = await getInspectedTabUrl().catch(() => null);
    let targetOrigin = null;
    if (currentHrefResult) {
      try {
        const current = new URL(currentHrefResult);
        targetOrigin = current.origin;
      } catch {
        targetOrigin = null;
      }
    }

    let targetUrl;
    if (startUrl.startsWith("http") || !targetOrigin) {
      targetUrl = startUrl;
    } else {
      targetUrl = startUrl.startsWith("/") ? targetOrigin + startUrl : targetOrigin + "/" + startUrl;
    }

    chrome.tabs.update(tabId, { url: targetUrl });
  } catch (e) {
    alfLog("warn", "nepodarilo sa presmerovať po reset:", e && e.message ? e.message : e);
  }
}
